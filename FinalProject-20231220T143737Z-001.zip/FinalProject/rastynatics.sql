USE MASTER
GO

IF DB_ID('RMRSys') IS NOT NULL
	DROP DATABASE RMRSys

GO

CREATE DATABASE RMRSys

GO

USE RMRSys

GO

CREATE TABLE tblSubscriptionTypes (
	[SubTypeID] BIGINT CONSTRAINT pk_subtypeid PRIMARY KEY,
	[Type] CHAR(15) NOT NULL,
	[Price] MONEY NOT NULL
)


CREATE TABLE tblUsers (
	[UserID] BIGINT CONSTRAINT pk_userid PRIMARY KEY,
	[FirstName] VARCHAR(50) NOT NULL,
	[LastName] VARCHAR(50) NOT NULL,
	[Address] VARCHAR(50) NOT NULL,
	[Username] VARCHAR(50) NOT NULL,
	[Password] VARCHAR(50) NOT NULL,
	[IsAdmin] BIT DEFAULT 0 NOT NULL
)

CREATE TABLE tblSubscriptions (
	[SubscriptionID] BIGINT IDENTITY(1, 1) CONSTRAINT pk_subscriptionid PRIMARY KEY,
	[SubTypeID] BIGINT CONSTRAINT fk_subscriptions_subtypeid FOREIGN KEY REFERENCES tblSubscriptionTypes(SubTypeID) NOT NULL,
	[UserID] BIGINT CONSTRAINT fk_subscriptions_userid FOREIGN KEY REFERENCES tblUsers(UserID) NOT NULL,
	[EndDate] DATETIME NOT NULL,
	[Payment] MONEY NOT NULL,
	[Expired] BIT DEFAULT 0 NOT NULL
)

CREATE TABLE tblGenres (
	[GenreID] BIGINT CONSTRAINT pk_genreid PRIMARY KEY,
	[Genre] CHAR(20) NOT NULL
)

CREATE TABLE tblMovies (
	[MovieID] VARCHAR(10) CONSTRAINT pk_movieid PRIMARY KEY,
	[Title] VARCHAR(50) NOT NULL,
	[ReleaseDate] DATE NOT NULL
)


CREATE TABLE tblMovieDetails (
	[MovieDetailsID] BIGINT IDENTITY(1, 1) CONSTRAINT pk_moviedetailsid PRIMARY KEY,
	[MovieID] VARCHAR(10) CONSTRAINT fk_moviedetails_movieid FOREIGN KEY REFERENCES tblMovies(MovieID) NOT NULL,
	[GenreID] BIGINT CONSTRAINT fk_moviedetails_genreid FOREIGN KEY REFERENCES tblGenres(GenreID) NOT NULL
)

CREATE TABLE tblMovieRentals (
	[MovieRentalID] BIGINT IDENTITY(1, 1) CONSTRAINT pk_movierentalid PRIMARY KEY,
	[UserID] BIGINT CONSTRAINT fk_movierentals_userid FOREIGN KEY REFERENCES tblUsers(UserID) NOT NULL,
	[StartDate] DATETIME DEFAULT CONVERT(DATETIME, GETDATE()) NOT NULL,
	[EndDate] DATETIME NOT NULL,
	[TotalPayment] MONEY NOT NULL
)

CREATE TABLE tblRentalDetails (
	[RentalDetailsID] BIGINT IDENTITY(1, 1) CONSTRAINT pk_rentaldetailsid PRIMARY KEY,
	[MovieRentalID] BIGINT CONSTRAINT fk_rentalid FOREIGN KEY REFERENCES tblMovieRentals(MovieRentalID) NOT NULL,
	[MovieID] VARCHAR(10) CONSTRAINT fk_movierentals_movieid FOREIGN KEY REFERENCES tblMovies(MovieID) NOT NULL,
	[Payment] MONEY NOT NULL,
	[IsReturned] BIT DEFAULT 0 NOT NULL,
	[HasAccess] BIT DEFAULT 1 NOT NULL
)

GO
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Users

INSERT INTO tblUsers (UserId, FirstName, LastName, Address, Username, Password) VALUES (1, 'Bogart', 'Gwapo', 'Mandaue City', 'bogartgwapz', 'gwapz1234')
INSERT INTO tblUsers (UserId, FirstName, LastName, Address, Username, Password, IsAdmin) VALUES (2, 'Giyuu', 'Tomioka', 'Mandaue City', 'hmmm', 'meh4321', 1)
INSERT INTO tblUsers (UserId, FirstName, LastName, Address, Username, Password) VALUES (3, 'James', 'Reid', 'Cebu City', 'jamesgwapo', 'gwapojames')
INSERT INTO tblUsers (UserId, FirstName, LastName, Address, Username, Password) VALUES (4, 'Angelina', 'Jolie', 'Lapu-Lapu City', 'dyosa123', 'tignawng333')
INSERT INTO tblUsers (UserId, FirstName, LastName, Address, Username, Password) VALUES (5, 'Andrew', 'Tits', 'Amerika City', 'pawiks', 'sinaw143')
INSERT INTO tblUsers (UserId, FirstName, LastName, Address, Username, Password) VALUES (6, 'Lebron', 'Gems', 'Carcar City', 'bolador', 'forthr333')

-------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Movies
INSERT INTO tblMovies VALUES ('DSM-200001', 'Demon Slayer The Movie: Mugen Train','2020-10-16')
INSERT INTO tblMovies VALUES ('PRL-220002', 'Pearl', '2022-09-16')
INSERT INTO tblMovies VALUES ('EEA-220003', 'Everything Everywhere All At Once', '2022-03-25')
INSERT INTO tblMovies VALUES ('EXE-220004', 'X', '2022-03-18')
INSERT INTO tblMovies VALUES ('MSR-190005', 'Midsommar', '2019-07-03')
INSERT INTO tblMovies VALUES ('SPA-010006', 'Spirited Away',  '2001-07-20')
INSERT INTO tblMovies VALUES ('TSC-080007', 'The Spiderwick Chronicles', '2008-02-14')
INSERT INTO tblMovies VALUES ('B13-040008', 'District B13', '2004-11-10')
INSERT INTO tblMovies VALUES ('AVR-220009', 'Avatar: The Way of Water', '2022-12-14')
INSERT INTO tblMovies VALUES ('THR-220010', 'Thor: Love and Thunder', '2022-07-08')
INSERT INTO tblMovies VALUES ('CLB-160011', 'Collateral Beauty', '2016-12-16')
INSERT INTO tblMovies VALUES ('JW3-190012', 'John Wick: Chapter - 3 Parabellum', '2019-05-17')
INSERT INTO tblMovies VALUES ('AEG-190013', 'Avengers: Endgame', '2019-04-24')
INSERT INTO tblMovies VALUES ('PCD-170014', 'Pirates of the Caribbean: Dead Men Tell No Tales', '2017-05-26')

-------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Genre
INSERT INTO tblGenres VALUES (1, 'Animation')
INSERT INTO tblGenres VALUES (2, 'Action')
INSERT INTO tblGenres VALUES (3, 'Adventure')
INSERT INTO tblGenres VALUES (4, 'Comedy')
INSERT INTO tblGenres VALUES (5, 'Drama')
INSERT INTO tblGenres VALUES (6, 'Fantasy')
INSERT INTO tblGenres VALUES (7, 'Horror')
INSERT INTO tblGenres VALUES (8, 'Science Fiction')
INSERT INTO tblGenres VALUES (9, 'Romance')

-------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Movie Details
INSERT INTO tblMovieDetails VALUES ('DSM-200001', 1)
INSERT INTO tblMovieDetails VALUES ('DSM-200001', 2)
INSERT INTO tblMovieDetails VALUES ('DSM-200001', 3)
INSERT INTO tblMovieDetails VALUES ('DSM-200001', 6)
INSERT INTO tblMovieDetails VALUES ('PRL-220002', 7)
INSERT INTO tblMovieDetails VALUES ('PRL-220002', 5)
INSERT INTO tblMovieDetails VALUES ('EEA-220003', 2)
INSERT INTO tblMovieDetails VALUES ('EEA-220003', 3)
INSERT INTO tblMovieDetails VALUES ('EEA-220003', 8)
INSERT INTO tblMovieDetails VALUES ('EXE-220004', 7)
INSERT INTO tblMovieDetails VALUES ('MSR-190005', 5)
INSERT INTO tblMovieDetails VALUES ('MSR-190005', 7)
INSERT INTO tblMovieDetails VALUES ('SPA-010006', 1)
INSERT INTO tblMovieDetails VALUES ('SPA-010006', 6)
INSERT INTO tblMovieDetails VALUES ('TSC-080007', 3)
INSERT INTO tblMovieDetails VALUES ('TSC-080007', 5)
INSERT INTO tblMovieDetails VALUES ('TSC-080007', 6)
INSERT INTO tblMovieDetails VALUES ('B13-040008', 2)
INSERT INTO tblMovieDetails VALUES ('B13-040008', 8)
INSERT INTO tblMovieDetails VALUES ('AVR-220009', 2)
INSERT INTO tblMovieDetails VALUES ('AVR-220009', 3)
INSERT INTO tblMovieDetails VALUES ('AVR-220009', 8)
INSERT INTO tblMovieDetails VALUES ('THR-220010', 2)
INSERT INTO tblMovieDetails VALUES ('THR-220010', 6)
INSERT INTO tblMovieDetails VALUES ('THR-220010', 4)
INSERT INTO tblMovieDetails VALUES ('CLB-160011', 5)
INSERT INTO tblMovieDetails VALUES ('CLB-160011', 9)
INSERT INTO tblMovieDetails VALUES ('JW3-190012', 2)
INSERT INTO tblMovieDetails VALUES ('AEG-190013', 2)
INSERT INTO tblMovieDetails VALUES ('AEG-190013', 3)
INSERT INTO tblMovieDetails VALUES ('AEG-190013', 8)
INSERT INTO tblMovieDetails VALUES ('PCD-170014', 2)
INSERT INTO tblMovieDetails VALUES ('PCD-170014', 3)
INSERT INTO tblMovieDetails VALUES ('PCD-170014', 6)

-------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Subscription Types
INSERT INTO tblSubscriptionTypes VALUES (1, 'Basic', 50)
INSERT INTO tblSubscriptionTypes VALUES (2, 'Standard', 100)
INSERT INTO tblSubscriptionTypes VALUES (3, 'Premium', 150)

-------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Subscriptions
INSERT INTO tblSubscriptions (SubTypeID, UserID, EndDate, Payment) VALUES (3, 1, '2023-01-16', 150)
INSERT INTO tblSubscriptions (SubTypeID, UserID, EndDate, Payment) VALUES (3, 3, '2023-01-16', 150)
INSERT INTO tblSubscriptions (SubTypeID, UserID, EndDate, Payment) VALUES (3, 4, '2023-01-16', 150)
INSERT INTO tblSubscriptions (SubTypeID, UserID, EndDate, Payment) VALUES (3, 5, '2023-01-16', 150)
INSERT INTO tblSubscriptions (SubTypeID, UserID, EndDate, Payment) VALUES (3, 6, '2023-01-16', 150)


-------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Movie Rentals
INSERT INTO tblMovieRentals (UserID, EndDate, TotalPayment) VALUES (1, '2023-01-15', 400)

-------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Rental Details
INSERT INTO tblRentalDetails (MovieRentalID, MovieID, Payment) VALUES (1, 'DSM-200001', 200)
INSERT INTO tblRentalDetails (MovieRentalID, MovieID, Payment) VALUES (1, 'B13-040008', 200)
-------------------------------------------------------------------------------------------------------------------------------------------------------------
--Views
-------------------------------------------------------------------------------------------------------------------------------------------------------------
GO
-- View sa movies
CREATE VIEW moviesView AS
	SELECT MovieID, Title, Genre =
	STUFF((
				SELECT ', ' + TRIM(Genre)
				FROM tblMovieDetails, tblGenres 
				WHERE tblMovieDetails.GenreID = tblGenres.GenreID AND tblMovies.MovieID = tblMovieDetails.MovieID
				FOR XML PATH('')), 1, 1, ''), ReleaseDate
	FROM tblMovies

GO

-- View sa users
CREATE VIEW usersView AS
	SELECT [tblUsers].[UserID], [FirstName], [LastName], [Address], [Username], [Password], [Type], [EndDate], [Expired] FROM tblUsers
	INNER JOIN tblSubscriptions ON tblSubscriptions.UserID = tblUsers.UserID
	INNER JOIN tblSubscriptionTypes ON tblSubscriptionTypes.SubTypeID = tblSubscriptions.SubTypeID

GO

CREATE VIEW rentalsView AS
	SELECT RentalDetailsID, UserID, Title, Payment, StartDate, EndDate, IsReturned, HasAccess FROM tblMovieRentals
	INNER JOIN tblRentalDetails ON tblRentalDetails.MovieRentalID = tblMovieRentals.MovieRentalID
	INNER JOIN tblMovies ON tblMovies.MovieID = tblRentalDetails.MovieID

GO
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Kuwang pa? Dugangi.. jk ay kasuko heeh