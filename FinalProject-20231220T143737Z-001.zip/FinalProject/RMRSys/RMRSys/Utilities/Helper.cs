﻿using RMRSys.Forms;
using RMRSys.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMRSys.Utilities
{
    public static class Helper
    {
        public static void ChangeForm(Form from, Form to)
        {
            from.Hide();
            to.ShowDialog();
            from.Close();
        }

        public static bool Mbox(string message, string caption, MessageBoxButtons btn = MessageBoxButtons.OK, MessageBoxIcon icon = MessageBoxIcon.Information, DialogResult res = DialogResult.OK)
        {
            return MessageBox.Show(message, caption, btn, icon) == res;
        }

        public static RMRSysEntities UpdateMovieDetails(RMRSysEntities db, tblMovieDetails genre, CheckBox chkBox, TextBox newMovieID, string oldMovieID, TextBox Title, TextBox ReleaseDate)
        {
            if (chkBox.Checked == false)
            {
                if (genre != null)
                {
                    if (newMovieID.Text.Trim() != oldMovieID) { db.keyError = true; return db; }

                    genre.tblMovies.Title = Title.Text.Trim();
                    genre.tblMovies.ReleaseDate = Convert.ToDateTime(ReleaseDate.Text);

                    db.tblMovieDetails.Remove(genre);
                    db.countUpdated += 1;
                }
                else { return db; }
            }
            else if (chkBox.Checked == true)
            {
                if (genre == null)
                {
                    if (newMovieID.Text.Trim() != oldMovieID) { db.keyError = true; return db; }

                    tblMovieDetails newDetails = new tblMovieDetails()
                    {
                        MovieID = newMovieID.Text.Trim(),
                        GenreID = db.tblGenres.Where(x => x.Genre.Trim() == chkBox.Text).FirstOrDefault().GenreID
                    };
                    db.tblMovieDetails.Add(newDetails);
                    db.countUpdated += 1;
                }
                else 
                {
                    if (newMovieID.Text.Trim() != oldMovieID) { db.keyError = true; return db; }

                    genre.tblMovies.Title = Title.Text.Trim();
                    genre.tblMovies.ReleaseDate = Convert.ToDateTime(ReleaseDate.Text);
                }
            }
            return db;
        }

        public static void ClearHighlight(TextBox textBox)
        {
            textBox.SelectionStart = textBox.Text.Length;
        }

        public static void HighlightText(TextBox textBox)
        {
            textBox.SelectionStart = 0;
            textBox.SelectionLength = textBox.TextLength;
        }
    }
}
