﻿using RMRSys.Model;
using RMRSys.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMRSys.Forms
{
    public partial class FormAdminRentals : Form
    {
        public long adminID { get; set; }

        public FormAdminRentals(long adminID)
        {
            InitializeComponent();
            this.adminID = adminID;
        }

        private void FormAdminRentals_Load(object sender, EventArgs e)
        {
            LoadGrids();
        }

        private void LoadGrids()
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                this.usersViewBindingSource.DataSource = db.usersView.ToList();
                this.rentalsViewBindingSource.DataSource = db.rentalsView.ToList();
            }

            foreach (DataGridViewRow row in gridUsers.Rows)
            {
                row.Cells[1].Value = $"{row.Cells[2].Value} {row.Cells[3].Value}";
            }
        }

        // Button click events
        private void BtnBack_Click(object sender, EventArgs e)
        {
            Helper.ChangeForm(this, new FormAdminHome(adminID));
        }

        // Grid Events
        private void GridUsers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            long userID = Convert.ToInt64(gridUsers.SelectedRows[0].Cells[0].Value);

            using (RMRSysEntities db = new RMRSysEntities())
            {
                usersView user = db.usersView.Where(x => x.UserID == userID).FirstOrDefault();
                txtBoxUserID.Text = userID.ToString();
                txtBoxFirstName.Text = user.FirstName;
                txtBoxLastName.Text = user.LastName;
                txtBoxAddress.Text = user.Address;
                txtBoxUsername.Text = user.Username;
                txtBoxSubscription.Text = user.Expired == true ? "No subscription" : user.Type.Trim();
                txtBoxEnd.Text = user.EndDate.ToString("yyyy-MM-dd hh:mm tt");
                this.rentalsViewBindingSource.DataSource = db.rentalsView.Where(x => x.UserID == userID).ToList();
            }
        }


        // text Changed Event
        private void TxtBoxUserID_MouseUp(object sender, MouseEventArgs e)
        {
            Helper.ClearHighlight(txtBoxUserID);
        }

        private void TxtBoxUsername_MouseUp(object sender, MouseEventArgs e)
        {
            Helper.ClearHighlight(txtBoxUsername);
        }

        private void TxtBoxFirstName_MouseUp(object sender, MouseEventArgs e)
        {
            Helper.ClearHighlight(txtBoxFirstName);
        }

        private void TxtBoxLastName_MouseUp(object sender, MouseEventArgs e)
        {
            Helper.ClearHighlight(txtBoxLastName);
        }

        private void TxtBoxAddress_MouseUp(object sender, MouseEventArgs e)
        {
            Helper.ClearHighlight(txtBoxAddress);
        }

        private void TxtBoxSubscription_MouseUp(object sender, MouseEventArgs e)
        {
            Helper.ClearHighlight(txtBoxSubscription);
        }

        private void TxtBoxEnd_MouseUp(object sender, MouseEventArgs e)
        {
            Helper.ClearHighlight(txtBoxEnd);
        }
    }
}
