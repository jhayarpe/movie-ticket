﻿namespace RMRSys.Forms
{
    partial class FormUserHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUser = new System.Windows.Forms.Label();
            this.menuUser = new System.Windows.Forms.MenuStrip();
            this.toolStripBrowse = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripRentals = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSubscription = new System.Windows.Forms.ToolStripMenuItem();
            this.btnLogout = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuUser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(14, 239);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(106, 16);
            this.lblUser.TabIndex = 11;
            this.lblUser.Text = "Current User:  ";
            // 
            // menuUser
            // 
            this.menuUser.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuUser.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuUser.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripBrowse,
            this.toolStripRentals,
            this.toolStripSubscription});
            this.menuUser.Location = new System.Drawing.Point(0, 0);
            this.menuUser.Name = "menuUser";
            this.menuUser.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.menuUser.Size = new System.Drawing.Size(471, 26);
            this.menuUser.TabIndex = 12;
            // 
            // toolStripBrowse
            // 
            this.toolStripBrowse.Name = "toolStripBrowse";
            this.toolStripBrowse.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.toolStripBrowse.Size = new System.Drawing.Size(130, 22);
            this.toolStripBrowse.Text = "&Browse Movies";
            this.toolStripBrowse.Click += new System.EventHandler(this.ToolStripBrowse_Click);
            // 
            // toolStripRentals
            // 
            this.toolStripRentals.Name = "toolStripRentals";
            this.toolStripRentals.Size = new System.Drawing.Size(131, 22);
            this.toolStripRentals.Text = "&Rented Movies";
            this.toolStripRentals.Click += new System.EventHandler(this.ToolStripRentals_Click);
            // 
            // toolStripSubscription
            // 
            this.toolStripSubscription.Name = "toolStripSubscription";
            this.toolStripSubscription.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.toolStripSubscription.Size = new System.Drawing.Size(107, 22);
            this.toolStripSubscription.Text = "&Subscription";
            this.toolStripSubscription.Click += new System.EventHandler(this.ToolStripSubscription_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.ForeColor = System.Drawing.Color.Red;
            this.btnLogout.Location = new System.Drawing.Point(375, 232);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 14;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::RMRSys.Properties.Resources.movie_icon;
            this.pictureBox1.Location = new System.Drawing.Point(40, 40);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(390, 186);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // FormUserHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(471, 264);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.menuUser);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuUser;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormUserHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.menuUser.ResumeLayout(false);
            this.menuUser.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.MenuStrip menuUser;
        private System.Windows.Forms.ToolStripMenuItem toolStripBrowse;
        private System.Windows.Forms.ToolStripMenuItem toolStripRentals;
        private System.Windows.Forms.ToolStripMenuItem toolStripSubscription;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnLogout;
    }
}