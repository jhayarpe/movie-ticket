﻿namespace RMRSys.Forms
{
    partial class FormAdminHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.adminMenu = new System.Windows.Forms.MenuStrip();
            this.menuMovies = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRentals = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblUser = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.adminMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // adminMenu
            // 
            this.adminMenu.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.adminMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuMovies,
            this.menuRentals});
            this.adminMenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.adminMenu.Location = new System.Drawing.Point(0, 0);
            this.adminMenu.Name = "adminMenu";
            this.adminMenu.Size = new System.Drawing.Size(471, 26);
            this.adminMenu.TabIndex = 0;
            // 
            // menuMovies
            // 
            this.menuMovies.Name = "menuMovies";
            this.menuMovies.Size = new System.Drawing.Size(74, 22);
            this.menuMovies.Text = "&Movies";
            this.menuMovies.Click += new System.EventHandler(this.MenuMovies_Click);
            // 
            // menuRentals
            // 
            this.menuRentals.Name = "menuRentals";
            this.menuRentals.Size = new System.Drawing.Size(198, 22);
            this.menuRentals.Text = "&Rentals and Subscribers";
            this.menuRentals.Click += new System.EventHandler(this.MenuRentals_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::RMRSys.Properties.Resources.movie_icon;
            this.pictureBox1.Location = new System.Drawing.Point(40, 40);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(390, 186);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(14, 239);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(106, 16);
            this.lblUser.TabIndex = 15;
            this.lblUser.Text = "Current User:  ";
            // 
            // btnLogout
            // 
            this.btnLogout.ForeColor = System.Drawing.Color.Red;
            this.btnLogout.Location = new System.Drawing.Point(375, 232);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 16;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.BtnLogout_Click);
            // 
            // FormAdminHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(471, 264);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.adminMenu);
            this.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.adminMenu;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAdminHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.adminMenu.ResumeLayout(false);
            this.adminMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip adminMenu;
        private System.Windows.Forms.ToolStripMenuItem menuMovies;
        private System.Windows.Forms.ToolStripMenuItem menuRentals;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Button btnLogout;
    }
}