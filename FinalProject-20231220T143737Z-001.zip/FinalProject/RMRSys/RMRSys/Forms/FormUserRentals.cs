﻿using RMRSys.Model;
using RMRSys.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMRSys.Forms
{
    public partial class FormUserRentals : Form
    {
        public long userID { get; set; }

        public FormUserRentals(long userID)
        {
            InitializeComponent();
            this.userID = userID;
        }

        private void FormUserRentals_Load(object sender, EventArgs e)
        {
            LoadGrid();
        }

        private void LoadGrid()
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                this.rentalsViewBindingSource.DataSource = db.rentalsView.Where(x => x.UserID == userID && x.HasAccess == true).ToList();
            }
        }

        private void BtnWatch_Click(object sender, EventArgs e)
        {
            if (gridRentals.Rows.Count == 0) { return; }

            Helper.Mbox($"Now Playing: {gridRentals.SelectedRows[0].Cells[2].Value}", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnReturn_Click(object sender, EventArgs e)
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                if (gridRentals.Rows.Count == 0) { return; }

                if (Helper.Mbox("Are you sure?", "Return", MessageBoxButtons.YesNo, MessageBoxIcon.Question, DialogResult.Yes))
                {
                    long rentalDetailsID = Convert.ToInt64(gridRentals.SelectedRows[0].Cells[0].Value);
                    tblRentalDetails details = db.tblRentalDetails.Where(x => x.RentalDetailsID == rentalDetailsID).FirstOrDefault();
                    details.IsReturned = true;
                    details.HasAccess = false;

                    Helper.Mbox("Successfully returned! Thank you for using our rental services!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    db.SaveChanges();

                    LoadGrid();
                }
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            Helper.ChangeForm(this, new FormUserHome(userID));
        }
    }
}
