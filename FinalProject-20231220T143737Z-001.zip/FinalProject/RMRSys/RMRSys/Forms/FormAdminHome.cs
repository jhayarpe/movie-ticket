﻿using RMRSys.Model;
using RMRSys.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMRSys.Forms
{
    public partial class FormAdminHome : Form
    {
        public long adminID { get; set; }
        public FormAdminHome(long adminID)
        {
            InitializeComponent();
            this.adminID = adminID;

            using (RMRSysEntities db = new RMRSysEntities())
            {
                tblUsers user = db.tblUsers.Where(x => x.UserID == adminID).FirstOrDefault();
                this.lblUser.Text += $" {user.FirstName} {user.LastName}";
            }
        }

        // Button events

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            if (Helper.Mbox("Are you sure?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question, DialogResult.Yes))
            {
                Helper.ChangeForm(this, new FormLogin());
            }
        }

        // Menu events
        private void MenuMovies_Click(object sender, EventArgs e)
        {
            Helper.ChangeForm(this, new FormAdminMovies(adminID));
        }

        private void MenuRentals_Click(object sender, EventArgs e)
        {
            Helper.ChangeForm(this, new FormAdminRentals(adminID));
        }
    }
}
