﻿namespace RMRSys.Forms
{
    partial class FormUserMovies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtBoxTitle = new System.Windows.Forms.TextBox();
            this.lblRent = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grpBoxSearch = new System.Windows.Forms.GroupBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnFilter = new System.Windows.Forms.Button();
            this.txtBoxYear = new System.Windows.Forms.TextBox();
            this.cmBoxGenre = new System.Windows.Forms.ComboBox();
            this.gridMovies = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.moviesViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnRent = new System.Windows.Forms.Button();
            this.grpBoxFilter = new System.Windows.Forms.GroupBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.grpBoxSort = new System.Windows.Forms.GroupBox();
            this.rBtnReleaseDate = new System.Windows.Forms.RadioButton();
            this.btnSort = new System.Windows.Forms.Button();
            this.rBtnGenre = new System.Windows.Forms.RadioButton();
            this.rBtnTitle = new System.Windows.Forms.RadioButton();
            this.grpBoxSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMovies)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.moviesViewBindingSource)).BeginInit();
            this.grpBoxFilter.SuspendLayout();
            this.grpBoxSort.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtBoxTitle
            // 
            this.txtBoxTitle.Location = new System.Drawing.Point(68, 29);
            this.txtBoxTitle.Name = "txtBoxTitle";
            this.txtBoxTitle.Size = new System.Drawing.Size(590, 23);
            this.txtBoxTitle.TabIndex = 0;
            // 
            // lblRent
            // 
            this.lblRent.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblRent.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRent.Location = new System.Drawing.Point(0, 0);
            this.lblRent.Name = "lblRent";
            this.lblRent.Size = new System.Drawing.Size(827, 63);
            this.lblRent.TabIndex = 9;
            this.lblRent.Text = "Rastynatics Movie Store";
            this.lblRent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Title:";
            // 
            // grpBoxSearch
            // 
            this.grpBoxSearch.Controls.Add(this.btnSearch);
            this.grpBoxSearch.Controls.Add(this.txtBoxTitle);
            this.grpBoxSearch.Controls.Add(this.label1);
            this.grpBoxSearch.Location = new System.Drawing.Point(33, 59);
            this.grpBoxSearch.Name = "grpBoxSearch";
            this.grpBoxSearch.Size = new System.Drawing.Size(759, 76);
            this.grpBoxSearch.TabIndex = 8;
            this.grpBoxSearch.TabStop = false;
            this.grpBoxSearch.Text = "Search by Movie Title";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(675, 29);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(70, 23);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // btnFilter
            // 
            this.btnFilter.Location = new System.Drawing.Point(245, 29);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(70, 23);
            this.btnFilter.TabIndex = 5;
            this.btnFilter.Text = "Filter";
            this.btnFilter.UseVisualStyleBackColor = true;
            this.btnFilter.Click += new System.EventHandler(this.BtnFilter_Click);
            // 
            // txtBoxYear
            // 
            this.txtBoxYear.Location = new System.Drawing.Point(139, 29);
            this.txtBoxYear.MaxLength = 4;
            this.txtBoxYear.Name = "txtBoxYear";
            this.txtBoxYear.Size = new System.Drawing.Size(100, 23);
            this.txtBoxYear.TabIndex = 4;
            this.txtBoxYear.Text = "Year";
            this.txtBoxYear.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TxtBoxYear_MouseClick);
            this.txtBoxYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBoxYear_KeyPress);
            // 
            // cmBoxGenre
            // 
            this.cmBoxGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmBoxGenre.FormattingEnabled = true;
            this.cmBoxGenre.Location = new System.Drawing.Point(29, 29);
            this.cmBoxGenre.Name = "cmBoxGenre";
            this.cmBoxGenre.Size = new System.Drawing.Size(104, 24);
            this.cmBoxGenre.TabIndex = 3;
            // 
            // gridMovies
            // 
            this.gridMovies.AllowUserToAddRows = false;
            this.gridMovies.AllowUserToDeleteRows = false;
            this.gridMovies.AllowUserToResizeColumns = false;
            this.gridMovies.AllowUserToResizeRows = false;
            this.gridMovies.AutoGenerateColumns = false;
            this.gridMovies.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridMovies.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridMovies.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.gridMovies.DataSource = this.moviesViewBindingSource;
            this.gridMovies.Location = new System.Drawing.Point(33, 227);
            this.gridMovies.Name = "gridMovies";
            this.gridMovies.ReadOnly = true;
            this.gridMovies.RowHeadersVisible = false;
            this.gridMovies.RowHeadersWidth = 51;
            this.gridMovies.RowTemplate.Height = 24;
            this.gridMovies.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridMovies.Size = new System.Drawing.Size(759, 186);
            this.gridMovies.TabIndex = 1;
            this.gridMovies.TabStop = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "MovieID";
            this.dataGridViewTextBoxColumn1.HeaderText = "MovieID";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Title";
            this.dataGridViewTextBoxColumn2.HeaderText = "Title";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Genre";
            this.dataGridViewTextBoxColumn3.HeaderText = "Genre";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "ReleaseDate";
            dataGridViewCellStyle1.Format = "yyyy-MM-dd";
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewTextBoxColumn4.HeaderText = "ReleaseDate";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // moviesViewBindingSource
            // 
            this.moviesViewBindingSource.DataSource = typeof(RMRSys.Model.moviesView);
            // 
            // btnRent
            // 
            this.btnRent.Location = new System.Drawing.Point(646, 432);
            this.btnRent.Name = "btnRent";
            this.btnRent.Size = new System.Drawing.Size(70, 23);
            this.btnRent.TabIndex = 6;
            this.btnRent.Text = "Rent";
            this.btnRent.UseVisualStyleBackColor = true;
            this.btnRent.Click += new System.EventHandler(this.BtnRent_Click);
            // 
            // grpBoxFilter
            // 
            this.grpBoxFilter.Controls.Add(this.cmBoxGenre);
            this.grpBoxFilter.Controls.Add(this.btnFilter);
            this.grpBoxFilter.Controls.Add(this.txtBoxYear);
            this.grpBoxFilter.Location = new System.Drawing.Point(463, 141);
            this.grpBoxFilter.Name = "grpBoxFilter";
            this.grpBoxFilter.Size = new System.Drawing.Size(329, 75);
            this.grpBoxFilter.TabIndex = 0;
            this.grpBoxFilter.TabStop = false;
            this.grpBoxFilter.Text = "Filter";
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.Red;
            this.btnBack.Location = new System.Drawing.Point(722, 432);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(70, 23);
            this.btnBack.TabIndex = 7;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // grpBoxSort
            // 
            this.grpBoxSort.Controls.Add(this.rBtnReleaseDate);
            this.grpBoxSort.Controls.Add(this.btnSort);
            this.grpBoxSort.Controls.Add(this.rBtnGenre);
            this.grpBoxSort.Controls.Add(this.rBtnTitle);
            this.grpBoxSort.Location = new System.Drawing.Point(33, 141);
            this.grpBoxSort.Name = "grpBoxSort";
            this.grpBoxSort.Size = new System.Drawing.Size(403, 75);
            this.grpBoxSort.TabIndex = 11;
            this.grpBoxSort.TabStop = false;
            this.grpBoxSort.Text = "Sort";
            // 
            // rBtnReleaseDate
            // 
            this.rBtnReleaseDate.AutoSize = true;
            this.rBtnReleaseDate.Location = new System.Drawing.Point(180, 29);
            this.rBtnReleaseDate.Name = "rBtnReleaseDate";
            this.rBtnReleaseDate.Size = new System.Drawing.Size(114, 20);
            this.rBtnReleaseDate.TabIndex = 2;
            this.rBtnReleaseDate.TabStop = true;
            this.rBtnReleaseDate.Text = "Release Date";
            this.rBtnReleaseDate.UseVisualStyleBackColor = true;
            // 
            // btnSort
            // 
            this.btnSort.Location = new System.Drawing.Point(312, 28);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(70, 23);
            this.btnSort.TabIndex = 5;
            this.btnSort.Text = "Sort";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.BtnSort_Click);
            // 
            // rBtnGenre
            // 
            this.rBtnGenre.AutoSize = true;
            this.rBtnGenre.Location = new System.Drawing.Point(102, 30);
            this.rBtnGenre.Name = "rBtnGenre";
            this.rBtnGenre.Size = new System.Drawing.Size(66, 20);
            this.rBtnGenre.TabIndex = 1;
            this.rBtnGenre.TabStop = true;
            this.rBtnGenre.Text = "Genre";
            this.rBtnGenre.UseVisualStyleBackColor = true;
            // 
            // rBtnTitle
            // 
            this.rBtnTitle.AutoSize = true;
            this.rBtnTitle.Location = new System.Drawing.Point(33, 30);
            this.rBtnTitle.Name = "rBtnTitle";
            this.rBtnTitle.Size = new System.Drawing.Size(57, 20);
            this.rBtnTitle.TabIndex = 0;
            this.rBtnTitle.TabStop = true;
            this.rBtnTitle.Text = "Title";
            this.rBtnTitle.UseVisualStyleBackColor = true;
            // 
            // FormUserMovies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(827, 485);
            this.Controls.Add(this.grpBoxSort);
            this.Controls.Add(this.grpBoxFilter);
            this.Controls.Add(this.gridMovies);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnRent);
            this.Controls.Add(this.grpBoxSearch);
            this.Controls.Add(this.lblRent);
            this.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormUserMovies";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Browse Movies";
            this.Load += new System.EventHandler(this.FormUser_Load);
            this.grpBoxSearch.ResumeLayout(false);
            this.grpBoxSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMovies)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.moviesViewBindingSource)).EndInit();
            this.grpBoxFilter.ResumeLayout(false);
            this.grpBoxFilter.PerformLayout();
            this.grpBoxSort.ResumeLayout(false);
            this.grpBoxSort.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox txtBoxTitle;
        private System.Windows.Forms.Label lblRent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpBoxSearch;
        private System.Windows.Forms.ComboBox cmBoxGenre;
        private System.Windows.Forms.DataGridView gridMovies;
        private System.Windows.Forms.TextBox txtBoxYear;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.Button btnRent;
        private System.Windows.Forms.GroupBox grpBoxFilter;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.BindingSource moviesViewBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.GroupBox grpBoxSort;
        private System.Windows.Forms.RadioButton rBtnTitle;
        private System.Windows.Forms.RadioButton rBtnReleaseDate;
        private System.Windows.Forms.RadioButton rBtnGenre;
        private System.Windows.Forms.Button btnSort;
    }
}