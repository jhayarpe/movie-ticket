﻿using RMRSys.Model;
using RMRSys.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMRSys.Forms
{
    public partial class FormUserHome : Form
    {
        public long userID { get; set; }

        public FormUserHome(long userID)
        {
            InitializeComponent();
            this.userID = userID;

            using (RMRSysEntities db = new RMRSysEntities())
            {
                tblUsers user = db.tblUsers.Where(x => x.UserID == userID).FirstOrDefault();
                lblUser.Text += $" {user.FirstName} {user.LastName}";
            }
        }

        private void ToolStripBrowse_Click(object sender, EventArgs e)
        {
            Helper.ChangeForm(this, new FormUserMovies(userID));
        }

        private void ToolStripRentals_Click(object sender, EventArgs e)
        {
            Helper.ChangeForm(this, new FormUserRentals(userID));
        }

        private void ToolStripSubscription_Click(object sender, EventArgs e)
        {
            Helper.ChangeForm(this, new FormUserSubscription(userID));
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (Helper.Mbox("Are you sure?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question, DialogResult.Yes)) 
            {
                Helper.ChangeForm(this, new FormLogin());
            }
        }
    }
}
