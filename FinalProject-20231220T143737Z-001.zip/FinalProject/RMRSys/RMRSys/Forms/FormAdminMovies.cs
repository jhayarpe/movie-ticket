﻿using RMRSys.Model;
using RMRSys.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMRSys.Forms
{
    public partial class FormAdminMovies : Form
    {
        public long adminID { get; set; }
        public string oldMovieID { get; set; }
        public string title { get; set; }
        public string genre { get; set; }
        public string releaseDate { get; set; }

        public FormAdminMovies(long adminID)
        {
            InitializeComponent();
            this.adminID = adminID;
        }

        private void FormAdminMovies_Load(object sender, EventArgs e)
        {
            InitializeComboBox();
            LoadGrid();
            rBtnTitle.Checked = true;
        }

        private void InitializeComboBox()
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                List<tblGenres> genre = db.tblGenres.ToList();
                AddItem(genre, typeof(tblGenres), "Genre", "GenreID", "Select Genre");
                cmBoxGenre.DataSource = genre;
                cmBoxGenre.DisplayMember = "Genre";
                cmBoxGenre.ValueMember = "GenreID";
            }
        }

        private void AddItem(IList list, Type type, string displayMember, string ValueMember, string displayText)
        {
            Object obj = Activator.CreateInstance(type);
            PropertyInfo displayProperty = type.GetProperty(displayMember);
            displayProperty.SetValue(obj, displayText);
            PropertyInfo valueProperty = type.GetProperty(ValueMember);
            valueProperty.SetValue(obj, 0);
            list.Insert(0, obj);
        }

        private void LoadGrid()
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                this.moviesViewBindingSource.DataSource = db.moviesView.OrderBy(x => x.Title).ToList();
            }
        }

        // Grid Events
        private void GridMovies_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            chkAction.Checked = chkAdventure.Checked = chkAnimation.Checked = chkComedy.Checked = chkDrama.Checked = chkFantasy.Checked = chkHorror.Checked = chkScienceFiction.Checked = false;
            string movieID = gridMovies.SelectedRows[0].Cells[0].Value.ToString();
            oldMovieID = movieID;

            using (RMRSysEntities db = new RMRSysEntities())
            {
                var details = db.tblMovieDetails.Where(x => x.MovieID == movieID);
                foreach (var item in details)
                {
                    txtBoxMovieID.Text = item.MovieID;
                    txtBoxTitle.Text = item.tblMovies.Title;
                    txtBoxReleaseDate.Text = item.tblMovies.ReleaseDate.ToString("yyyy-MM-dd");
                    switch (item.tblGenres.Genre.Trim())
                    {
                        case "Action":
                            chkAction.Checked = true;
                            break;
                        case "Adventure":
                            chkAdventure.Checked = true;
                            break;
                        case "Animation":
                            chkAnimation.Checked = true;
                            break;
                        case "Comedy":
                            chkComedy.Checked = true;
                            break;
                        case "Drama":
                            chkDrama.Checked = true;
                            break;
                        case "Fantasy":
                            chkFantasy.Checked = true;
                            break;
                        case "Horror":
                            chkHorror.Checked = true;
                            break;
                        case "Science Fiction":
                            chkScienceFiction.Checked = true;
                            break;
                    }
                }
            }
        }

        // Button Events
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                var countChecked = grpMod.Controls.OfType<CheckBox>().Count(x => x.Checked);
                var findID = db.tblMovies.Find(txtBoxMovieID.Text.Trim());

                if (IsIncomplete()) { Helper.Mbox("Please fill up all the required fields.", "Error"); return; }

                if (countChecked == 0) { Helper.Mbox("A movie should have at least a single genre.", "Error"); return; }

                if (findID != null) { Helper.Mbox("MovieID should be unique.", "Error"); return; }

                if (Helper.Mbox("Are you sure?", "Add", MessageBoxButtons.YesNo, MessageBoxIcon.Question, DialogResult.Yes))
                {
                    tblMovies movie = new tblMovies()
                    {
                        MovieID = txtBoxMovieID.Text.Trim(),
                        Title = txtBoxTitle.Text.Trim(),
                        ReleaseDate = Convert.ToDateTime(txtBoxReleaseDate.Text)
                    };
                    db.tblMovies.Add(movie);
                    foreach (var item in grpMod.Controls.OfType<CheckBox>().Where(x => x.Checked))
                    {
                        tblMovieDetails details = new tblMovieDetails()
                        {
                            MovieID = txtBoxMovieID.Text.Trim(),
                            GenreID = db.tblGenres.Where(x => x.Genre.Trim() == item.Text).FirstOrDefault().GenreID
                        };
                        db.tblMovieDetails.Add(details);
                    }
                }
                MessageBox.Show("Successfully added!");
                db.SaveChanges();

                // Retain filters
                title = txtBoxTitle.Text.Trim();
                genre = cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem).Trim() == "Select Genre" ? "" : cmBoxGenre.GetItemText(cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem)).Trim();
                releaseDate = txtBoxYear.Text.Trim() == "Year" ? "" : txtBoxYear.Text.Trim();

                this.moviesViewBindingSource.DataSource = db.moviesView.OrderBy(x => x.Title).ToList();
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                var countChecked = grpMod.Controls.OfType<CheckBox>().Count(x => x.Checked);

                if (IsIncomplete()) { Helper.Mbox("Please fill up all the required fields.", "Error"); return; }

                if (countChecked == 0) { Helper.Mbox("A movie should have at least a single genre.", "Error"); return; }

                if (Helper.Mbox("Are you sure?", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question, DialogResult.Yes))
                {
                    tblMovies movieID = db.tblMovies.Where(x => x.MovieID == txtBoxMovieID.Text.Trim()).FirstOrDefault();
                    
                    foreach (var item in grpMod.Controls.OfType<CheckBox>())
                    {
                        switch (item.Text)
                        {
                            case "Action":
                                var action = db.tblMovieDetails.Where(x => x.MovieID == txtBoxMovieID.Text && x.tblGenres.Genre == "Action").FirstOrDefault();
                                Helper.UpdateMovieDetails(db, action, chkAction, txtBoxMovieID, oldMovieID, txtBoxTitle, txtBoxReleaseDate);
                                break;
                            case "Adventure":
                                var adventure = db.tblMovieDetails.Where(x => x.MovieID == txtBoxMovieID.Text && x.tblGenres.Genre == "Adventure").FirstOrDefault();
                                Helper.UpdateMovieDetails(db, adventure, chkAdventure, txtBoxMovieID, oldMovieID, txtBoxTitle, txtBoxReleaseDate);
                                break;
                            case "Animation":
                                var animation = db.tblMovieDetails.Where(x => x.MovieID == txtBoxMovieID.Text && x.tblGenres.Genre == "Animation").FirstOrDefault();
                                Helper.UpdateMovieDetails(db, animation, chkAnimation, txtBoxMovieID, oldMovieID, txtBoxTitle, txtBoxReleaseDate);
                                break;
                            case "Comedy":
                                var comedy = db.tblMovieDetails.Where(x => x.MovieID == txtBoxMovieID.Text && x.tblGenres.Genre == "Comedy").FirstOrDefault();
                                Helper.UpdateMovieDetails(db, comedy, chkComedy, txtBoxMovieID, oldMovieID, txtBoxTitle, txtBoxReleaseDate);
                                break;
                            case "Drama":
                                var drama = db.tblMovieDetails.Where(x => x.MovieID == txtBoxMovieID.Text && x.tblGenres.Genre == "Drama").FirstOrDefault();
                                Helper.UpdateMovieDetails(db, drama, chkDrama, txtBoxMovieID, oldMovieID, txtBoxTitle, txtBoxReleaseDate);
                                break;
                            case "Fantasy":
                                var fantasy = db.tblMovieDetails.Where(x => x.MovieID == txtBoxMovieID.Text && x.tblGenres.Genre == "Fantasy").FirstOrDefault();
                                Helper.UpdateMovieDetails(db, fantasy, chkFantasy, txtBoxMovieID, oldMovieID, txtBoxTitle, txtBoxReleaseDate);
                                break;
                            case "Horror":
                                var horror = db.tblMovieDetails.Where(x => x.MovieID == txtBoxMovieID.Text && x.tblGenres.Genre == "Horror").FirstOrDefault();
                                Helper.UpdateMovieDetails(db, horror, chkHorror, txtBoxMovieID, oldMovieID, txtBoxTitle, txtBoxReleaseDate);
                                break;
                            case "Science Fiction":
                                var science_fiction = db.tblMovieDetails.Where(x => x.MovieID == txtBoxMovieID.Text && x.tblGenres.Genre == "Science Fiction").FirstOrDefault();
                                Helper.UpdateMovieDetails(db, science_fiction, chkScienceFiction, txtBoxMovieID, oldMovieID, txtBoxTitle, txtBoxReleaseDate);
                                break;
                        }
                    }
                    if (db.keyError) { MessageBox.Show("MovieID should not be modified!"); }
                    if (db.countUpdated > 0) { MessageBox.Show("Successfully updated!"); }
                    db.SaveChanges();
                    // Retain filters
                    title = txtBoxTitle.Text.Trim();
                    genre = cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem).Trim() == "Select Genre" ? "" : cmBoxGenre.GetItemText(cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem)).Trim();
                    releaseDate = txtBoxYear.Text.Trim() == "Year" ? "" : txtBoxYear.Text.Trim();

                    this.moviesViewBindingSource.DataSource = db.moviesView.OrderBy(x => x.Title).ToList();
                }
            }
        }

        private void BtnClearModify_Click(object sender, EventArgs e)
        {
            foreach (var txtBox in grpMod.Controls.OfType<TextBox>())
            {
                txtBox.Clear();
                foreach (var chkBox in grpMod.Controls.OfType<CheckBox>())
                {
                    chkBox.Checked = false;
                }
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            foreach (var txtBox in grpMod.Controls.OfType<TextBox>())
            {
                txtBox.Clear();
                foreach (var chkBox in grpMod.Controls.OfType<CheckBox>())
                {
                    chkBox.Checked = false;
                }
            }

            txtBoxSearch.Text = "";
            txtBoxYear.Text = "Year";
            cmBoxGenre.SelectedIndex = 0;
            rBtnTitle.Checked = true;
            rBtnReleaseDate.Checked = false;
            rBtnGenre.Checked = false;

            using (RMRSysEntities db = new RMRSysEntities())
            {
                this.moviesViewBindingSource.DataSource = db.moviesView.OrderBy(x => x.Title).ToList();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            string movieID = gridMovies.SelectedRows[0].Cells[0].Value.ToString().Trim();
            using (RMRSysEntities db = new RMRSysEntities())
            {
                if (Helper.Mbox("Are you sure?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question, DialogResult.Yes))
                {
                    var moviedetails = db.tblMovieDetails.Where(x => x.MovieID == movieID).ToList();

                    foreach (tblMovieDetails detail in moviedetails)
                    {
                        db.tblMovieDetails.Remove(detail);
                    }

                    tblMovies movie = db.tblMovies.Where(x => x.MovieID == movieID).FirstOrDefault();
                    db.tblMovies.Remove(movie);
                    MessageBox.Show("Successfully deleted!");
                    db.SaveChanges();
                    this.moviesViewBindingSource.DataSource = db.moviesView.ToList();
                }
            }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                title = txtBoxSearch.Text.Trim();
                this.moviesViewBindingSource.DataSource = db.moviesView.Where(x => x.Title.Contains(title)).OrderBy(x => x.Title).ToList();
            }
        }

        private void BtnSort_Click(object sender, EventArgs e)
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                title = txtBoxTitle.Text.Trim();
                genre = cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem).Trim() == "Select Genre" ? "" : cmBoxGenre.GetItemText(cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem)).Trim();
                releaseDate = txtBoxYear.Text.Trim() == "Year" ? "" : txtBoxYear.Text.Trim();

                if (rBtnTitle.Checked)
                {
                    this.moviesViewBindingSource.DataSource = db.moviesView.Where(x => x.Title.Contains(title) && x.Genre.Contains(genre) && x.ReleaseDate.Year.ToString().Contains(releaseDate)).OrderBy(x => x.Title).ToList();
                }
                else if (rBtnGenre.Checked)
                {
                    this.moviesViewBindingSource.DataSource = db.moviesView.Where(x => x.Title.Contains(title) && x.Genre.Contains(genre) && x.ReleaseDate.Year.ToString().Contains(releaseDate)).OrderBy(x => x.Genre).ToList();
                }
                else
                {
                    this.moviesViewBindingSource.DataSource = db.moviesView.Where(x => x.Title.Contains(title) && x.Genre.Contains(genre) && x.ReleaseDate.Year.ToString().Contains(releaseDate)).OrderBy(x => x.ReleaseDate).ToList();
                }
            }
        }

        private void BtnFilter_Click(object sender, EventArgs e)
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                title = txtBoxTitle.Text.Trim();
                genre = cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem).Trim() == "Select Genre" ? "" : cmBoxGenre.GetItemText(cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem)).Trim();
                releaseDate = txtBoxYear.Text.Trim() == "Year" ? "" : txtBoxYear.Text.Trim();


                this.moviesViewBindingSource.DataSource = db.moviesView.Where(x => x.Title.Contains(title) && x.Genre.Contains(genre) && x.ReleaseDate.Year.ToString().Contains(releaseDate)).OrderBy(x => x.Title).ToList();
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            Helper.ChangeForm(this, new FormAdminHome(adminID));
        }

        private bool IsIncomplete()
        {
            foreach (var txtBox in grpMod.Controls.OfType<TextBox>())
            {
                if (txtBox.Text == "") { return true; }
            }
            return false;
        }
    }
}
