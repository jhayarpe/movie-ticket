﻿using RMRSys.Model;
using RMRSys.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMRSys.Forms
{
    public partial class FormUserRent : Form
    {
        public long userID { get; set; }
        public DateTime returnDate { get; set; }
        public ArrayList selectedMovies { get; set; }

        public FormUserRent(long userID, ArrayList selectedMovies)
        {
            InitializeComponent();
            this.userID = userID;
            this.selectedMovies = selectedMovies;

            
        }

        private void FormRent_Load(object sender, EventArgs e)
        {
            InitializeControls();
        }

        // Initialize controls
        private void InitializeControls()
        {
            this.moviesViewBindingSource.DataSource = this.selectedMovies;
            
            foreach (DataGridViewColumn col in gridCart.Columns)
            {
                col.SortMode = DataGridViewColumnSortMode.NotSortable;
            }


            foreach (DataGridViewRow row in gridCart.Rows)
            {
                row.Cells[4].Value = "Remove";
            }

            UpdateTotalPayment();
            InitializeReturnDate();
            txtBoxDateEnd.Text = returnDate.ToString("yyyy-MM-dd");
        }

        // update total payment
        private void UpdateTotalPayment()
        {
            txtTotalPayment.Text = $"Php {(200 * (int)gridCart.Rows.Count)}";
        }

        // initialize return date
        private void InitializeReturnDate()
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                tblSubscriptions sub = db.tblSubscriptions.Where(x => x.UserID == userID).FirstOrDefault();

                if (sub.tblSubscriptionTypes.Type == "Basic")
                {
                    returnDate = DateTime.Now.AddDays(7);
                }
                else if (sub.tblSubscriptionTypes.Type == "Standard")
                {
                    returnDate = DateTime.Now.AddDays(14);
                }
                else
                {
                    returnDate = DateTime.Now.AddDays(30);
                }
            }
        }

        // Button Events
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            if (Helper.Mbox("Are you sure?", "Information", MessageBoxButtons.YesNo, MessageBoxIcon.Information, DialogResult.Yes))
            {
                Helper.ChangeForm(this, new FormUserMovies(userID));
            }
        }

        private void BtnCheckOut_Click(object sender, EventArgs e)
        {
            if (gridCart.Rows.Count == 0) { MessageBox.Show("Add something to your cart."); return; }
            using (RMRSysEntities db = new RMRSysEntities())
            {
                if (Helper.Mbox("Are you sure?", "Checkout", MessageBoxButtons.YesNo, MessageBoxIcon.Question, DialogResult.Yes))
                {
                    // Insert rentals
                    tblMovieRentals rentals = new tblMovieRentals()
                    {
                        UserID = userID,
                        EndDate = Convert.ToDateTime(txtBoxDateEnd.Text),
                        TotalPayment = Convert.ToDecimal(txtTotalPayment.Text.Substring(4))
                    };
                    db.tblMovieRentals.Add(rentals);

                    // Insert rental details
                    var curID = db.Database.SqlQuery<long>("SELECT MAX(MovieRentalID) FROM tblMovieRentals").Single() + 1;
                    foreach (DataGridViewRow row in gridCart.Rows)
                    {
                        tblRentalDetails rentalDetails = new tblRentalDetails()
                        {
                            MovieRentalID = curID,
                            MovieID = row.Cells[0].Value.ToString().Trim(),
                            Payment = 200
                        };
                        db.tblRentalDetails.Add(rentalDetails);
                    }
                    db.SaveChanges();
                    Helper.Mbox("Purchase successful!", "Success");
                    Helper.ChangeForm(this, new FormUserMovies(userID));
                }
            }
        }
        
        // Grid events
        private void GridCart_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 4)
            {
                if (Helper.Mbox("Are you sure?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, DialogResult.Yes))
                {
                    gridCart.Rows.RemoveAt(e.RowIndex);
                }
            }

            UpdateTotalPayment();
        }

        // auto clear on read only
        private void TxtTotalPayment_MouseUp(object sender, MouseEventArgs e)
        {
            txtTotalPayment.SelectionStart = txtTotalPayment.Text.Length;
        }

        private void TxtBoxDateEnd_MouseUp(object sender, MouseEventArgs e)
        {
            txtBoxDateEnd.SelectionStart = txtBoxDateEnd.Text.Length;
        }
    }
}
