﻿namespace RMRSys.Forms
{
    partial class FormAdminRentals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.grpUserInformation = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxLastName = new System.Windows.Forms.TextBox();
            this.txtBoxUsername = new System.Windows.Forms.TextBox();
            this.txtBoxAddress = new System.Windows.Forms.TextBox();
            this.txtBoxEnd = new System.Windows.Forms.TextBox();
            this.txtBoxSubscription = new System.Windows.Forms.TextBox();
            this.txtBoxFirstName = new System.Windows.Forms.TextBox();
            this.txtBoxUserID = new System.Windows.Forms.TextBox();
            this.gridUsers = new System.Windows.Forms.DataGridView();
            this.userIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FullName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usersViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridRentalDetails = new System.Windows.Forms.DataGridView();
            this.rentalDetailsIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.titleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.endDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isReturnedDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.hasAccessDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.rentalsViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnBack = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.grpUserInformation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridRentalDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalsViewBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // grpUserInformation
            // 
            this.grpUserInformation.Controls.Add(this.label9);
            this.grpUserInformation.Controls.Add(this.label6);
            this.grpUserInformation.Controls.Add(this.label5);
            this.grpUserInformation.Controls.Add(this.label4);
            this.grpUserInformation.Controls.Add(this.label3);
            this.grpUserInformation.Controls.Add(this.label2);
            this.grpUserInformation.Controls.Add(this.label1);
            this.grpUserInformation.Controls.Add(this.txtBoxLastName);
            this.grpUserInformation.Controls.Add(this.txtBoxUsername);
            this.grpUserInformation.Controls.Add(this.txtBoxAddress);
            this.grpUserInformation.Controls.Add(this.txtBoxEnd);
            this.grpUserInformation.Controls.Add(this.txtBoxSubscription);
            this.grpUserInformation.Controls.Add(this.txtBoxFirstName);
            this.grpUserInformation.Controls.Add(this.txtBoxUserID);
            this.grpUserInformation.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold);
            this.grpUserInformation.Location = new System.Drawing.Point(38, 30);
            this.grpUserInformation.Name = "grpUserInformation";
            this.grpUserInformation.Size = new System.Drawing.Size(758, 236);
            this.grpUserInformation.TabIndex = 0;
            this.grpUserInformation.TabStop = false;
            this.grpUserInformation.Text = "User Information";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.label9.Location = new System.Drawing.Point(438, 180);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 16);
            this.label9.TabIndex = 4;
            this.label9.Text = "End Date: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.label6.Location = new System.Drawing.Point(438, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 16);
            this.label6.TabIndex = 4;
            this.label6.Text = "Last Name: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.label5.Location = new System.Drawing.Point(438, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Username: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.label4.Location = new System.Drawing.Point(40, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Subscription: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.label3.Location = new System.Drawing.Point(40, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Address: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.label2.Location = new System.Drawing.Point(40, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "First Name: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.label1.Location = new System.Drawing.Point(40, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "UserID: ";
            // 
            // txtBoxLastName
            // 
            this.txtBoxLastName.BackColor = System.Drawing.Color.White;
            this.txtBoxLastName.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.txtBoxLastName.Location = new System.Drawing.Point(534, 89);
            this.txtBoxLastName.Name = "txtBoxLastName";
            this.txtBoxLastName.ReadOnly = true;
            this.txtBoxLastName.Size = new System.Drawing.Size(176, 23);
            this.txtBoxLastName.TabIndex = 3;
            this.txtBoxLastName.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TxtBoxLastName_MouseUp);
            // 
            // txtBoxUsername
            // 
            this.txtBoxUsername.BackColor = System.Drawing.Color.White;
            this.txtBoxUsername.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.txtBoxUsername.Location = new System.Drawing.Point(534, 45);
            this.txtBoxUsername.Name = "txtBoxUsername";
            this.txtBoxUsername.ReadOnly = true;
            this.txtBoxUsername.Size = new System.Drawing.Size(176, 23);
            this.txtBoxUsername.TabIndex = 3;
            this.txtBoxUsername.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TxtBoxUsername_MouseUp);
            // 
            // txtBoxAddress
            // 
            this.txtBoxAddress.BackColor = System.Drawing.Color.White;
            this.txtBoxAddress.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.txtBoxAddress.Location = new System.Drawing.Point(149, 133);
            this.txtBoxAddress.Name = "txtBoxAddress";
            this.txtBoxAddress.ReadOnly = true;
            this.txtBoxAddress.Size = new System.Drawing.Size(561, 23);
            this.txtBoxAddress.TabIndex = 3;
            this.txtBoxAddress.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TxtBoxAddress_MouseUp);
            // 
            // txtBoxEnd
            // 
            this.txtBoxEnd.BackColor = System.Drawing.Color.White;
            this.txtBoxEnd.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.txtBoxEnd.Location = new System.Drawing.Point(534, 177);
            this.txtBoxEnd.Name = "txtBoxEnd";
            this.txtBoxEnd.ReadOnly = true;
            this.txtBoxEnd.Size = new System.Drawing.Size(176, 23);
            this.txtBoxEnd.TabIndex = 3;
            this.txtBoxEnd.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TxtBoxEnd_MouseUp);
            // 
            // txtBoxSubscription
            // 
            this.txtBoxSubscription.BackColor = System.Drawing.Color.White;
            this.txtBoxSubscription.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.txtBoxSubscription.Location = new System.Drawing.Point(149, 177);
            this.txtBoxSubscription.Name = "txtBoxSubscription";
            this.txtBoxSubscription.ReadOnly = true;
            this.txtBoxSubscription.Size = new System.Drawing.Size(176, 23);
            this.txtBoxSubscription.TabIndex = 3;
            this.txtBoxSubscription.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TxtBoxSubscription_MouseUp);
            // 
            // txtBoxFirstName
            // 
            this.txtBoxFirstName.BackColor = System.Drawing.Color.White;
            this.txtBoxFirstName.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.txtBoxFirstName.Location = new System.Drawing.Point(149, 89);
            this.txtBoxFirstName.Name = "txtBoxFirstName";
            this.txtBoxFirstName.ReadOnly = true;
            this.txtBoxFirstName.Size = new System.Drawing.Size(176, 23);
            this.txtBoxFirstName.TabIndex = 3;
            this.txtBoxFirstName.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TxtBoxFirstName_MouseUp);
            // 
            // txtBoxUserID
            // 
            this.txtBoxUserID.BackColor = System.Drawing.Color.White;
            this.txtBoxUserID.Font = new System.Drawing.Font("Verdana", 7.8F);
            this.txtBoxUserID.Location = new System.Drawing.Point(149, 45);
            this.txtBoxUserID.Name = "txtBoxUserID";
            this.txtBoxUserID.ReadOnly = true;
            this.txtBoxUserID.Size = new System.Drawing.Size(176, 23);
            this.txtBoxUserID.TabIndex = 3;
            this.txtBoxUserID.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TxtBoxUserID_MouseUp);
            // 
            // gridUsers
            // 
            this.gridUsers.AllowUserToAddRows = false;
            this.gridUsers.AllowUserToDeleteRows = false;
            this.gridUsers.AllowUserToResizeColumns = false;
            this.gridUsers.AllowUserToResizeRows = false;
            this.gridUsers.AutoGenerateColumns = false;
            this.gridUsers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridUsers.ColumnHeadersHeight = 29;
            this.gridUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridUsers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.userIDDataGridViewTextBoxColumn,
            this.FullName,
            this.firstNameDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.usernameDataGridViewTextBoxColumn,
            this.passwordDataGridViewTextBoxColumn,
            this.typeDataGridViewTextBoxColumn});
            this.gridUsers.DataSource = this.usersViewBindingSource;
            this.gridUsers.Location = new System.Drawing.Point(829, 49);
            this.gridUsers.MultiSelect = false;
            this.gridUsers.Name = "gridUsers";
            this.gridUsers.ReadOnly = true;
            this.gridUsers.RowHeadersVisible = false;
            this.gridUsers.RowHeadersWidth = 51;
            this.gridUsers.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gridUsers.RowTemplate.Height = 24;
            this.gridUsers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridUsers.Size = new System.Drawing.Size(300, 528);
            this.gridUsers.TabIndex = 1;
            this.gridUsers.TabStop = false;
            this.gridUsers.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridUsers_CellClick);
            // 
            // userIDDataGridViewTextBoxColumn
            // 
            this.userIDDataGridViewTextBoxColumn.DataPropertyName = "UserID";
            this.userIDDataGridViewTextBoxColumn.FillWeight = 40F;
            this.userIDDataGridViewTextBoxColumn.HeaderText = "UserID";
            this.userIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.userIDDataGridViewTextBoxColumn.Name = "userIDDataGridViewTextBoxColumn";
            this.userIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // FullName
            // 
            this.FullName.HeaderText = "Full Name";
            this.FullName.MinimumWidth = 6;
            this.FullName.Name = "FullName";
            this.FullName.ReadOnly = true;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.firstNameDataGridViewTextBoxColumn.Visible = false;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.lastNameDataGridViewTextBoxColumn.Visible = false;
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.ReadOnly = true;
            this.addressDataGridViewTextBoxColumn.Visible = false;
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "Username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "Username";
            this.usernameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            this.usernameDataGridViewTextBoxColumn.ReadOnly = true;
            this.usernameDataGridViewTextBoxColumn.Visible = false;
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "Password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "Password";
            this.passwordDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            this.passwordDataGridViewTextBoxColumn.ReadOnly = true;
            this.passwordDataGridViewTextBoxColumn.Visible = false;
            // 
            // typeDataGridViewTextBoxColumn
            // 
            this.typeDataGridViewTextBoxColumn.DataPropertyName = "Type";
            this.typeDataGridViewTextBoxColumn.HeaderText = "Type";
            this.typeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.typeDataGridViewTextBoxColumn.Name = "typeDataGridViewTextBoxColumn";
            this.typeDataGridViewTextBoxColumn.ReadOnly = true;
            this.typeDataGridViewTextBoxColumn.Visible = false;
            // 
            // usersViewBindingSource
            // 
            this.usersViewBindingSource.DataSource = typeof(RMRSys.Model.usersView);
            // 
            // gridRentalDetails
            // 
            this.gridRentalDetails.AllowUserToAddRows = false;
            this.gridRentalDetails.AllowUserToDeleteRows = false;
            this.gridRentalDetails.AllowUserToResizeColumns = false;
            this.gridRentalDetails.AllowUserToResizeRows = false;
            this.gridRentalDetails.AutoGenerateColumns = false;
            this.gridRentalDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridRentalDetails.ColumnHeadersHeight = 29;
            this.gridRentalDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridRentalDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rentalDetailsIDDataGridViewTextBoxColumn,
            this.userIDDataGridViewTextBoxColumn1,
            this.titleDataGridViewTextBoxColumn,
            this.paymentDataGridViewTextBoxColumn,
            this.startDateDataGridViewTextBoxColumn,
            this.endDateDataGridViewTextBoxColumn,
            this.isReturnedDataGridViewCheckBoxColumn,
            this.hasAccessDataGridViewCheckBoxColumn});
            this.gridRentalDetails.DataSource = this.rentalsViewBindingSource;
            this.gridRentalDetails.Location = new System.Drawing.Point(38, 313);
            this.gridRentalDetails.MultiSelect = false;
            this.gridRentalDetails.Name = "gridRentalDetails";
            this.gridRentalDetails.ReadOnly = true;
            this.gridRentalDetails.RowHeadersVisible = false;
            this.gridRentalDetails.RowHeadersWidth = 51;
            this.gridRentalDetails.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gridRentalDetails.RowTemplate.Height = 24;
            this.gridRentalDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridRentalDetails.Size = new System.Drawing.Size(758, 264);
            this.gridRentalDetails.TabIndex = 1;
            this.gridRentalDetails.TabStop = false;
            // 
            // rentalDetailsIDDataGridViewTextBoxColumn
            // 
            this.rentalDetailsIDDataGridViewTextBoxColumn.DataPropertyName = "RentalDetailsID";
            this.rentalDetailsIDDataGridViewTextBoxColumn.FillWeight = 20F;
            this.rentalDetailsIDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.rentalDetailsIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.rentalDetailsIDDataGridViewTextBoxColumn.Name = "rentalDetailsIDDataGridViewTextBoxColumn";
            this.rentalDetailsIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // userIDDataGridViewTextBoxColumn1
            // 
            this.userIDDataGridViewTextBoxColumn1.DataPropertyName = "UserID";
            this.userIDDataGridViewTextBoxColumn1.FillWeight = 40F;
            this.userIDDataGridViewTextBoxColumn1.HeaderText = "UserID";
            this.userIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.userIDDataGridViewTextBoxColumn1.Name = "userIDDataGridViewTextBoxColumn1";
            this.userIDDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // titleDataGridViewTextBoxColumn
            // 
            this.titleDataGridViewTextBoxColumn.DataPropertyName = "Title";
            this.titleDataGridViewTextBoxColumn.FillWeight = 150F;
            this.titleDataGridViewTextBoxColumn.HeaderText = "Title";
            this.titleDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.titleDataGridViewTextBoxColumn.Name = "titleDataGridViewTextBoxColumn";
            this.titleDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // paymentDataGridViewTextBoxColumn
            // 
            this.paymentDataGridViewTextBoxColumn.DataPropertyName = "Payment";
            dataGridViewCellStyle1.Format = "C2";
            dataGridViewCellStyle1.NullValue = null;
            this.paymentDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.paymentDataGridViewTextBoxColumn.FillWeight = 80F;
            this.paymentDataGridViewTextBoxColumn.HeaderText = "Payment";
            this.paymentDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.paymentDataGridViewTextBoxColumn.Name = "paymentDataGridViewTextBoxColumn";
            this.paymentDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // startDateDataGridViewTextBoxColumn
            // 
            this.startDateDataGridViewTextBoxColumn.DataPropertyName = "StartDate";
            dataGridViewCellStyle2.Format = "yyyy-MM-dd hh:mm tt";
            dataGridViewCellStyle2.NullValue = null;
            this.startDateDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.startDateDataGridViewTextBoxColumn.HeaderText = "StartDate";
            this.startDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.startDateDataGridViewTextBoxColumn.Name = "startDateDataGridViewTextBoxColumn";
            this.startDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // endDateDataGridViewTextBoxColumn
            // 
            this.endDateDataGridViewTextBoxColumn.DataPropertyName = "EndDate";
            dataGridViewCellStyle3.Format = "yyyy-MM-dd hh:mm tt";
            dataGridViewCellStyle3.NullValue = null;
            this.endDateDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.endDateDataGridViewTextBoxColumn.HeaderText = "EndDate";
            this.endDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.endDateDataGridViewTextBoxColumn.Name = "endDateDataGridViewTextBoxColumn";
            this.endDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // isReturnedDataGridViewCheckBoxColumn
            // 
            this.isReturnedDataGridViewCheckBoxColumn.DataPropertyName = "IsReturned";
            this.isReturnedDataGridViewCheckBoxColumn.FillWeight = 80F;
            this.isReturnedDataGridViewCheckBoxColumn.HeaderText = "IsReturned";
            this.isReturnedDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.isReturnedDataGridViewCheckBoxColumn.Name = "isReturnedDataGridViewCheckBoxColumn";
            this.isReturnedDataGridViewCheckBoxColumn.ReadOnly = true;
            this.isReturnedDataGridViewCheckBoxColumn.Visible = false;
            // 
            // hasAccessDataGridViewCheckBoxColumn
            // 
            this.hasAccessDataGridViewCheckBoxColumn.DataPropertyName = "HasAccess";
            this.hasAccessDataGridViewCheckBoxColumn.FillWeight = 80F;
            this.hasAccessDataGridViewCheckBoxColumn.HeaderText = "HasAccess";
            this.hasAccessDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.hasAccessDataGridViewCheckBoxColumn.Name = "hasAccessDataGridViewCheckBoxColumn";
            this.hasAccessDataGridViewCheckBoxColumn.ReadOnly = true;
            this.hasAccessDataGridViewCheckBoxColumn.Visible = false;
            // 
            // rentalsViewBindingSource
            // 
            this.rentalsViewBindingSource.DataSource = typeof(RMRSys.Model.rentalsView);
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.Red;
            this.btnBack.Location = new System.Drawing.Point(1054, 588);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(35, 285);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 16);
            this.label7.TabIndex = 4;
            this.label7.Text = "Rental Details: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(826, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 16);
            this.label8.TabIndex = 5;
            this.label8.Text = "Users: ";
            // 
            // FormAdminRentals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1171, 627);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.gridRentalDetails);
            this.Controls.Add(this.gridUsers);
            this.Controls.Add(this.grpUserInformation);
            this.Controls.Add(this.label7);
            this.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAdminRentals";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rentals and Subscriptions";
            this.Load += new System.EventHandler(this.FormAdminRentals_Load);
            this.grpUserInformation.ResumeLayout(false);
            this.grpUserInformation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridRentalDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalsViewBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpUserInformation;
        private System.Windows.Forms.DataGridView gridUsers;
        private System.Windows.Forms.BindingSource usersViewBindingSource;
        private System.Windows.Forms.DataGridView gridRentalDetails;
        private System.Windows.Forms.BindingSource rentalsViewBindingSource;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox txtBoxLastName;
        private System.Windows.Forms.TextBox txtBoxUsername;
        private System.Windows.Forms.TextBox txtBoxAddress;
        private System.Windows.Forms.TextBox txtBoxFirstName;
        private System.Windows.Forms.TextBox txtBoxUserID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxSubscription;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewTextBoxColumn userIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn FullName;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentalDetailsIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn userIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn endDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isReturnedDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn hasAccessDataGridViewCheckBoxColumn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtBoxEnd;
    }
}