﻿namespace RMRSys.Forms
{
    partial class FormAdminMovies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gridMovies = new System.Windows.Forms.DataGridView();
            this.movieIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.titleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.releaseDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.moviesViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.grpMod = new System.Windows.Forms.GroupBox();
            this.btnClearModify = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.chkComedy = new System.Windows.Forms.CheckBox();
            this.chkAdventure = new System.Windows.Forms.CheckBox();
            this.chkAction = new System.Windows.Forms.CheckBox();
            this.chkScienceFiction = new System.Windows.Forms.CheckBox();
            this.chkHorror = new System.Windows.Forms.CheckBox();
            this.chkFantasy = new System.Windows.Forms.CheckBox();
            this.chkDrama = new System.Windows.Forms.CheckBox();
            this.chkAnimation = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxReleaseDate = new System.Windows.Forms.TextBox();
            this.txtBoxTitle = new System.Windows.Forms.TextBox();
            this.txtBoxMovieID = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.txtBoxSearch = new System.Windows.Forms.TextBox();
            this.grpBoxSort = new System.Windows.Forms.GroupBox();
            this.rBtnReleaseDate = new System.Windows.Forms.RadioButton();
            this.btnSort = new System.Windows.Forms.Button();
            this.rBtnGenre = new System.Windows.Forms.RadioButton();
            this.rBtnTitle = new System.Windows.Forms.RadioButton();
            this.grpBoxFilter = new System.Windows.Forms.GroupBox();
            this.cmBoxGenre = new System.Windows.Forms.ComboBox();
            this.btnFilter = new System.Windows.Forms.Button();
            this.txtBoxYear = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridMovies)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.moviesViewBindingSource)).BeginInit();
            this.grpMod.SuspendLayout();
            this.grpBoxSort.SuspendLayout();
            this.grpBoxFilter.SuspendLayout();
            this.SuspendLayout();
            // 
            // gridMovies
            // 
            this.gridMovies.AllowUserToAddRows = false;
            this.gridMovies.AllowUserToDeleteRows = false;
            this.gridMovies.AllowUserToResizeColumns = false;
            this.gridMovies.AllowUserToResizeRows = false;
            this.gridMovies.AutoGenerateColumns = false;
            this.gridMovies.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridMovies.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridMovies.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.movieIDDataGridViewTextBoxColumn,
            this.titleDataGridViewTextBoxColumn,
            this.genreDataGridViewTextBoxColumn,
            this.releaseDateDataGridViewTextBoxColumn});
            this.gridMovies.DataSource = this.moviesViewBindingSource;
            this.gridMovies.Location = new System.Drawing.Point(38, 385);
            this.gridMovies.MultiSelect = false;
            this.gridMovies.Name = "gridMovies";
            this.gridMovies.ReadOnly = true;
            this.gridMovies.RowHeadersVisible = false;
            this.gridMovies.RowHeadersWidth = 51;
            this.gridMovies.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gridMovies.RowTemplate.Height = 24;
            this.gridMovies.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridMovies.Size = new System.Drawing.Size(796, 227);
            this.gridMovies.TabIndex = 0;
            this.gridMovies.TabStop = false;
            this.gridMovies.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridMovies_CellClick);
            // 
            // movieIDDataGridViewTextBoxColumn
            // 
            this.movieIDDataGridViewTextBoxColumn.DataPropertyName = "MovieID";
            this.movieIDDataGridViewTextBoxColumn.FillWeight = 50F;
            this.movieIDDataGridViewTextBoxColumn.HeaderText = "MovieID";
            this.movieIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.movieIDDataGridViewTextBoxColumn.Name = "movieIDDataGridViewTextBoxColumn";
            this.movieIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // titleDataGridViewTextBoxColumn
            // 
            this.titleDataGridViewTextBoxColumn.DataPropertyName = "Title";
            this.titleDataGridViewTextBoxColumn.FillWeight = 130F;
            this.titleDataGridViewTextBoxColumn.HeaderText = "Title";
            this.titleDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.titleDataGridViewTextBoxColumn.Name = "titleDataGridViewTextBoxColumn";
            this.titleDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // genreDataGridViewTextBoxColumn
            // 
            this.genreDataGridViewTextBoxColumn.DataPropertyName = "Genre";
            this.genreDataGridViewTextBoxColumn.FillWeight = 70F;
            this.genreDataGridViewTextBoxColumn.HeaderText = "Genre";
            this.genreDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.genreDataGridViewTextBoxColumn.Name = "genreDataGridViewTextBoxColumn";
            this.genreDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // releaseDateDataGridViewTextBoxColumn
            // 
            this.releaseDateDataGridViewTextBoxColumn.DataPropertyName = "ReleaseDate";
            this.releaseDateDataGridViewTextBoxColumn.FillWeight = 50F;
            this.releaseDateDataGridViewTextBoxColumn.HeaderText = "ReleaseDate";
            this.releaseDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.releaseDateDataGridViewTextBoxColumn.Name = "releaseDateDataGridViewTextBoxColumn";
            this.releaseDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // moviesViewBindingSource
            // 
            this.moviesViewBindingSource.DataSource = typeof(RMRSys.Model.moviesView);
            // 
            // grpMod
            // 
            this.grpMod.Controls.Add(this.btnClearModify);
            this.grpMod.Controls.Add(this.btnDelete);
            this.grpMod.Controls.Add(this.btnUpdate);
            this.grpMod.Controls.Add(this.btnAdd);
            this.grpMod.Controls.Add(this.chkComedy);
            this.grpMod.Controls.Add(this.chkAdventure);
            this.grpMod.Controls.Add(this.chkAction);
            this.grpMod.Controls.Add(this.chkScienceFiction);
            this.grpMod.Controls.Add(this.chkHorror);
            this.grpMod.Controls.Add(this.chkFantasy);
            this.grpMod.Controls.Add(this.chkDrama);
            this.grpMod.Controls.Add(this.chkAnimation);
            this.grpMod.Controls.Add(this.label3);
            this.grpMod.Controls.Add(this.label4);
            this.grpMod.Controls.Add(this.label2);
            this.grpMod.Controls.Add(this.label1);
            this.grpMod.Controls.Add(this.txtBoxReleaseDate);
            this.grpMod.Controls.Add(this.txtBoxTitle);
            this.grpMod.Controls.Add(this.txtBoxMovieID);
            this.grpMod.Location = new System.Drawing.Point(38, 32);
            this.grpMod.Name = "grpMod";
            this.grpMod.Size = new System.Drawing.Size(796, 202);
            this.grpMod.TabIndex = 1;
            this.grpMod.TabStop = false;
            this.grpMod.Text = "Add/Modify Movies";
            // 
            // btnClearModify
            // 
            this.btnClearModify.ForeColor = System.Drawing.Color.Red;
            this.btnClearModify.Location = new System.Drawing.Point(602, 157);
            this.btnClearModify.Name = "btnClearModify";
            this.btnClearModify.Size = new System.Drawing.Size(75, 23);
            this.btnClearModify.TabIndex = 14;
            this.btnClearModify.Text = "Clear";
            this.btnClearModify.UseVisualStyleBackColor = true;
            this.btnClearModify.Click += new System.EventHandler(this.BtnClearModify_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.ForeColor = System.Drawing.Color.Red;
            this.btnDelete.Location = new System.Drawing.Point(690, 157);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 15;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(514, 157);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 13;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(426, 157);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // chkComedy
            // 
            this.chkComedy.AutoSize = true;
            this.chkComedy.Location = new System.Drawing.Point(632, 86);
            this.chkComedy.Name = "chkComedy";
            this.chkComedy.Size = new System.Drawing.Size(81, 20);
            this.chkComedy.TabIndex = 7;
            this.chkComedy.Text = "Comedy";
            this.chkComedy.UseVisualStyleBackColor = true;
            // 
            // chkAdventure
            // 
            this.chkAdventure.AutoSize = true;
            this.chkAdventure.Location = new System.Drawing.Point(400, 87);
            this.chkAdventure.Name = "chkAdventure";
            this.chkAdventure.Size = new System.Drawing.Size(97, 20);
            this.chkAdventure.TabIndex = 5;
            this.chkAdventure.Text = "Adventure";
            this.chkAdventure.UseVisualStyleBackColor = true;
            // 
            // chkAction
            // 
            this.chkAction.AutoSize = true;
            this.chkAction.Location = new System.Drawing.Point(310, 86);
            this.chkAction.Name = "chkAction";
            this.chkAction.Size = new System.Drawing.Size(71, 20);
            this.chkAction.TabIndex = 4;
            this.chkAction.Text = "Action";
            this.chkAction.UseVisualStyleBackColor = true;
            // 
            // chkScienceFiction
            // 
            this.chkScienceFiction.AutoSize = true;
            this.chkScienceFiction.Location = new System.Drawing.Point(632, 119);
            this.chkScienceFiction.Name = "chkScienceFiction";
            this.chkScienceFiction.Size = new System.Drawing.Size(130, 20);
            this.chkScienceFiction.TabIndex = 11;
            this.chkScienceFiction.Text = "Science Fiction";
            this.chkScienceFiction.UseVisualStyleBackColor = true;
            // 
            // chkHorror
            // 
            this.chkHorror.AutoSize = true;
            this.chkHorror.Location = new System.Drawing.Point(521, 119);
            this.chkHorror.Name = "chkHorror";
            this.chkHorror.Size = new System.Drawing.Size(69, 20);
            this.chkHorror.TabIndex = 10;
            this.chkHorror.Text = "Horror";
            this.chkHorror.UseVisualStyleBackColor = true;
            // 
            // chkFantasy
            // 
            this.chkFantasy.AutoSize = true;
            this.chkFantasy.Location = new System.Drawing.Point(402, 119);
            this.chkFantasy.Name = "chkFantasy";
            this.chkFantasy.Size = new System.Drawing.Size(81, 20);
            this.chkFantasy.TabIndex = 9;
            this.chkFantasy.Text = "Fantasy";
            this.chkFantasy.UseVisualStyleBackColor = true;
            // 
            // chkDrama
            // 
            this.chkDrama.AutoSize = true;
            this.chkDrama.Location = new System.Drawing.Point(310, 118);
            this.chkDrama.Name = "chkDrama";
            this.chkDrama.Size = new System.Drawing.Size(70, 20);
            this.chkDrama.TabIndex = 8;
            this.chkDrama.Text = "Drama";
            this.chkDrama.UseVisualStyleBackColor = true;
            // 
            // chkAnimation
            // 
            this.chkAnimation.AutoSize = true;
            this.chkAnimation.Location = new System.Drawing.Point(521, 86);
            this.chkAnimation.Name = "chkAnimation";
            this.chkAnimation.Size = new System.Drawing.Size(93, 20);
            this.chkAnimation.TabIndex = 6;
            this.chkAnimation.Text = "Animation";
            this.chkAnimation.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Release Date:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(253, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Genre:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(253, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Title: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Movie ID: ";
            // 
            // txtBoxReleaseDate
            // 
            this.txtBoxReleaseDate.Location = new System.Drawing.Point(136, 84);
            this.txtBoxReleaseDate.MaxLength = 10;
            this.txtBoxReleaseDate.Name = "txtBoxReleaseDate";
            this.txtBoxReleaseDate.Size = new System.Drawing.Size(100, 23);
            this.txtBoxReleaseDate.TabIndex = 3;
            // 
            // txtBoxTitle
            // 
            this.txtBoxTitle.Location = new System.Drawing.Point(306, 42);
            this.txtBoxTitle.Name = "txtBoxTitle";
            this.txtBoxTitle.Size = new System.Drawing.Size(407, 23);
            this.txtBoxTitle.TabIndex = 2;
            // 
            // txtBoxMovieID
            // 
            this.txtBoxMovieID.Location = new System.Drawing.Point(136, 42);
            this.txtBoxMovieID.MaxLength = 10;
            this.txtBoxMovieID.Name = "txtBoxMovieID";
            this.txtBoxMovieID.Size = new System.Drawing.Size(100, 23);
            this.txtBoxMovieID.TabIndex = 1;
            // 
            // btnClear
            // 
            this.btnClear.ForeColor = System.Drawing.Color.Red;
            this.btnClear.Location = new System.Drawing.Point(676, 627);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 14;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.Red;
            this.btnBack.Location = new System.Drawing.Point(759, 627);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 25;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // txtBoxSearch
            // 
            this.txtBoxSearch.Location = new System.Drawing.Point(103, 251);
            this.txtBoxSearch.Name = "txtBoxSearch";
            this.txtBoxSearch.Size = new System.Drawing.Size(629, 23);
            this.txtBoxSearch.TabIndex = 0;
            // 
            // grpBoxSort
            // 
            this.grpBoxSort.Controls.Add(this.rBtnReleaseDate);
            this.grpBoxSort.Controls.Add(this.btnSort);
            this.grpBoxSort.Controls.Add(this.rBtnGenre);
            this.grpBoxSort.Controls.Add(this.rBtnTitle);
            this.grpBoxSort.Location = new System.Drawing.Point(37, 286);
            this.grpBoxSort.Name = "grpBoxSort";
            this.grpBoxSort.Size = new System.Drawing.Size(403, 75);
            this.grpBoxSort.TabIndex = 17;
            this.grpBoxSort.TabStop = false;
            this.grpBoxSort.Text = "Sort";
            // 
            // rBtnReleaseDate
            // 
            this.rBtnReleaseDate.AutoSize = true;
            this.rBtnReleaseDate.Location = new System.Drawing.Point(180, 29);
            this.rBtnReleaseDate.Name = "rBtnReleaseDate";
            this.rBtnReleaseDate.Size = new System.Drawing.Size(114, 20);
            this.rBtnReleaseDate.TabIndex = 18;
            this.rBtnReleaseDate.TabStop = true;
            this.rBtnReleaseDate.Text = "Release Date";
            this.rBtnReleaseDate.UseVisualStyleBackColor = true;
            // 
            // btnSort
            // 
            this.btnSort.Location = new System.Drawing.Point(312, 28);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(70, 23);
            this.btnSort.TabIndex = 19;
            this.btnSort.Text = "Sort";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.BtnSort_Click);
            // 
            // rBtnGenre
            // 
            this.rBtnGenre.AutoSize = true;
            this.rBtnGenre.Location = new System.Drawing.Point(102, 30);
            this.rBtnGenre.Name = "rBtnGenre";
            this.rBtnGenre.Size = new System.Drawing.Size(66, 20);
            this.rBtnGenre.TabIndex = 16;
            this.rBtnGenre.TabStop = true;
            this.rBtnGenre.Text = "Genre";
            this.rBtnGenre.UseVisualStyleBackColor = true;
            // 
            // rBtnTitle
            // 
            this.rBtnTitle.AutoSize = true;
            this.rBtnTitle.Location = new System.Drawing.Point(33, 30);
            this.rBtnTitle.Name = "rBtnTitle";
            this.rBtnTitle.Size = new System.Drawing.Size(57, 20);
            this.rBtnTitle.TabIndex = 16;
            this.rBtnTitle.TabStop = true;
            this.rBtnTitle.Text = "Title";
            this.rBtnTitle.UseVisualStyleBackColor = true;
            // 
            // grpBoxFilter
            // 
            this.grpBoxFilter.Controls.Add(this.cmBoxGenre);
            this.grpBoxFilter.Controls.Add(this.btnFilter);
            this.grpBoxFilter.Controls.Add(this.txtBoxYear);
            this.grpBoxFilter.Location = new System.Drawing.Point(458, 286);
            this.grpBoxFilter.Name = "grpBoxFilter";
            this.grpBoxFilter.Size = new System.Drawing.Size(376, 75);
            this.grpBoxFilter.TabIndex = 16;
            this.grpBoxFilter.TabStop = false;
            this.grpBoxFilter.Text = "Filter";
            // 
            // cmBoxGenre
            // 
            this.cmBoxGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmBoxGenre.FormattingEnabled = true;
            this.cmBoxGenre.Location = new System.Drawing.Point(30, 29);
            this.cmBoxGenre.Name = "cmBoxGenre";
            this.cmBoxGenre.Size = new System.Drawing.Size(104, 24);
            this.cmBoxGenre.TabIndex = 20;
            // 
            // btnFilter
            // 
            this.btnFilter.Location = new System.Drawing.Point(276, 29);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(70, 23);
            this.btnFilter.TabIndex = 24;
            this.btnFilter.Text = "Filter";
            this.btnFilter.UseVisualStyleBackColor = true;
            this.btnFilter.Click += new System.EventHandler(this.BtnFilter_Click);
            // 
            // txtBoxYear
            // 
            this.txtBoxYear.Location = new System.Drawing.Point(156, 29);
            this.txtBoxYear.MaxLength = 4;
            this.txtBoxYear.Name = "txtBoxYear";
            this.txtBoxYear.Size = new System.Drawing.Size(100, 23);
            this.txtBoxYear.TabIndex = 21;
            this.txtBoxYear.Text = "Year";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(38, 254);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Search:";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(759, 252);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // FormAdminMovies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 658);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.grpBoxSort);
            this.Controls.Add(this.grpBoxFilter);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.grpMod);
            this.Controls.Add(this.gridMovies);
            this.Controls.Add(this.txtBoxSearch);
            this.Controls.Add(this.label5);
            this.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAdminMovies";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Movies";
            this.Load += new System.EventHandler(this.FormAdminMovies_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridMovies)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.moviesViewBindingSource)).EndInit();
            this.grpMod.ResumeLayout(false);
            this.grpMod.PerformLayout();
            this.grpBoxSort.ResumeLayout(false);
            this.grpBoxSort.PerformLayout();
            this.grpBoxFilter.ResumeLayout(false);
            this.grpBoxFilter.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView gridMovies;
        private System.Windows.Forms.GroupBox grpMod;
        private System.Windows.Forms.CheckBox chkAction;
        private System.Windows.Forms.CheckBox chkAnimation;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxReleaseDate;
        private System.Windows.Forms.TextBox txtBoxTitle;
        private System.Windows.Forms.TextBox txtBoxMovieID;
        private System.Windows.Forms.CheckBox chkComedy;
        private System.Windows.Forms.CheckBox chkAdventure;
        private System.Windows.Forms.CheckBox chkScienceFiction;
        private System.Windows.Forms.CheckBox chkHorror;
        private System.Windows.Forms.CheckBox chkFantasy;
        private System.Windows.Forms.CheckBox chkDrama;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.BindingSource moviesViewBindingSource;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtBoxSearch;
        private System.Windows.Forms.GroupBox grpBoxSort;
        private System.Windows.Forms.RadioButton rBtnReleaseDate;
        private System.Windows.Forms.Button btnSort;
        private System.Windows.Forms.RadioButton rBtnGenre;
        private System.Windows.Forms.RadioButton rBtnTitle;
        private System.Windows.Forms.GroupBox grpBoxFilter;
        private System.Windows.Forms.ComboBox cmBoxGenre;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.TextBox txtBoxYear;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn movieIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn releaseDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnClearModify;
    }
}