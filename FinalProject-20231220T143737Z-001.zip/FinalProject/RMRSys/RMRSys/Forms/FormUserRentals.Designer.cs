﻿namespace RMRSys.Forms
{
    partial class FormUserRentals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gridRentals = new System.Windows.Forms.DataGridView();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnWatch = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.rentalsViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rentalDetailsIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.titleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.endDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isReturnedDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.hasAccessDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gridRentals)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalsViewBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // gridRentals
            // 
            this.gridRentals.AllowUserToAddRows = false;
            this.gridRentals.AllowUserToDeleteRows = false;
            this.gridRentals.AllowUserToResizeColumns = false;
            this.gridRentals.AllowUserToResizeRows = false;
            this.gridRentals.AutoGenerateColumns = false;
            this.gridRentals.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridRentals.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridRentals.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rentalDetailsIDDataGridViewTextBoxColumn,
            this.userIDDataGridViewTextBoxColumn,
            this.titleDataGridViewTextBoxColumn,
            this.paymentDataGridViewTextBoxColumn,
            this.startDateDataGridViewTextBoxColumn,
            this.endDateDataGridViewTextBoxColumn,
            this.isReturnedDataGridViewCheckBoxColumn,
            this.hasAccessDataGridViewCheckBoxColumn});
            this.gridRentals.DataSource = this.rentalsViewBindingSource;
            this.gridRentals.Location = new System.Drawing.Point(46, 41);
            this.gridRentals.MultiSelect = false;
            this.gridRentals.Name = "gridRentals";
            this.gridRentals.ReadOnly = true;
            this.gridRentals.RowHeadersVisible = false;
            this.gridRentals.RowHeadersWidth = 51;
            this.gridRentals.RowTemplate.Height = 24;
            this.gridRentals.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridRentals.Size = new System.Drawing.Size(504, 202);
            this.gridRentals.TabIndex = 2;
            this.gridRentals.TabStop = false;
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(385, 258);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(75, 23);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.BtnReturn_Click);
            // 
            // btnWatch
            // 
            this.btnWatch.Location = new System.Drawing.Point(295, 258);
            this.btnWatch.Name = "btnWatch";
            this.btnWatch.Size = new System.Drawing.Size(75, 23);
            this.btnWatch.TabIndex = 3;
            this.btnWatch.Text = "Watch";
            this.btnWatch.UseVisualStyleBackColor = true;
            this.btnWatch.Click += new System.EventHandler(this.BtnWatch_Click);
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.Red;
            this.btnBack.Location = new System.Drawing.Point(475, 258);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 3;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // rentalsViewBindingSource
            // 
            this.rentalsViewBindingSource.DataSource = typeof(RMRSys.Model.rentalsView);
            // 
            // rentalDetailsIDDataGridViewTextBoxColumn
            // 
            this.rentalDetailsIDDataGridViewTextBoxColumn.DataPropertyName = "RentalDetailsID";
            this.rentalDetailsIDDataGridViewTextBoxColumn.HeaderText = "RentalDetailsID";
            this.rentalDetailsIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.rentalDetailsIDDataGridViewTextBoxColumn.Name = "rentalDetailsIDDataGridViewTextBoxColumn";
            this.rentalDetailsIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.rentalDetailsIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // userIDDataGridViewTextBoxColumn
            // 
            this.userIDDataGridViewTextBoxColumn.DataPropertyName = "UserID";
            this.userIDDataGridViewTextBoxColumn.HeaderText = "UserID";
            this.userIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.userIDDataGridViewTextBoxColumn.Name = "userIDDataGridViewTextBoxColumn";
            this.userIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.userIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // titleDataGridViewTextBoxColumn
            // 
            this.titleDataGridViewTextBoxColumn.DataPropertyName = "Title";
            this.titleDataGridViewTextBoxColumn.HeaderText = "Title";
            this.titleDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.titleDataGridViewTextBoxColumn.Name = "titleDataGridViewTextBoxColumn";
            this.titleDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // paymentDataGridViewTextBoxColumn
            // 
            this.paymentDataGridViewTextBoxColumn.DataPropertyName = "Payment";
            this.paymentDataGridViewTextBoxColumn.HeaderText = "Payment";
            this.paymentDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.paymentDataGridViewTextBoxColumn.Name = "paymentDataGridViewTextBoxColumn";
            this.paymentDataGridViewTextBoxColumn.ReadOnly = true;
            this.paymentDataGridViewTextBoxColumn.Visible = false;
            // 
            // startDateDataGridViewTextBoxColumn
            // 
            this.startDateDataGridViewTextBoxColumn.DataPropertyName = "StartDate";
            this.startDateDataGridViewTextBoxColumn.HeaderText = "StartDate";
            this.startDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.startDateDataGridViewTextBoxColumn.Name = "startDateDataGridViewTextBoxColumn";
            this.startDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.startDateDataGridViewTextBoxColumn.Visible = false;
            // 
            // endDateDataGridViewTextBoxColumn
            // 
            this.endDateDataGridViewTextBoxColumn.DataPropertyName = "EndDate";
            this.endDateDataGridViewTextBoxColumn.FillWeight = 50F;
            this.endDateDataGridViewTextBoxColumn.HeaderText = "EndDate";
            this.endDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.endDateDataGridViewTextBoxColumn.Name = "endDateDataGridViewTextBoxColumn";
            this.endDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // isReturnedDataGridViewCheckBoxColumn
            // 
            this.isReturnedDataGridViewCheckBoxColumn.DataPropertyName = "IsReturned";
            this.isReturnedDataGridViewCheckBoxColumn.HeaderText = "IsReturned";
            this.isReturnedDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.isReturnedDataGridViewCheckBoxColumn.Name = "isReturnedDataGridViewCheckBoxColumn";
            this.isReturnedDataGridViewCheckBoxColumn.ReadOnly = true;
            this.isReturnedDataGridViewCheckBoxColumn.Visible = false;
            // 
            // hasAccessDataGridViewCheckBoxColumn
            // 
            this.hasAccessDataGridViewCheckBoxColumn.DataPropertyName = "HasAccess";
            this.hasAccessDataGridViewCheckBoxColumn.HeaderText = "HasAccess";
            this.hasAccessDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.hasAccessDataGridViewCheckBoxColumn.Name = "hasAccessDataGridViewCheckBoxColumn";
            this.hasAccessDataGridViewCheckBoxColumn.ReadOnly = true;
            this.hasAccessDataGridViewCheckBoxColumn.Visible = false;
            // 
            // FormUserRentals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(595, 299);
            this.Controls.Add(this.btnWatch);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.gridRentals);
            this.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormUserRentals";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rented Movies";
            this.Load += new System.EventHandler(this.FormUserRentals_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridRentals)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalsViewBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gridRentals;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnWatch;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentalDetailsIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn userIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn endDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isReturnedDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn hasAccessDataGridViewCheckBoxColumn;
        private System.Windows.Forms.BindingSource rentalsViewBindingSource;
    }
}