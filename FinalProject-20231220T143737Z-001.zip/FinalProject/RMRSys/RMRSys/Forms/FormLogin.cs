﻿using RMRSys.Model;
using RMRSys.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMRSys.Forms
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }
        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                tblUsers user = db.tblUsers.Where(x => x.Username == txtBoxUsername.Text.Trim() && x.Password == txtBoxPassword.Text.Trim()).FirstOrDefault();
                if (user != null)
                {
                    if (user.IsAdmin == true)
                    {
                        Helper.Mbox("Login success!", "Information");
                        Helper.ChangeForm(this, new FormAdminHome((int)user.UserID));
                    }
                    else
                    {
                        Helper.Mbox("Login success!", "Information");
                        Helper.ChangeForm(this, new FormUserHome((int)user.UserID));
                    }
                }
                else { Helper.Mbox("Invalid Credentials", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (Helper.Mbox("Are you sure?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question, DialogResult.Yes)) { this.Close(); }
        }

        private void txtBoxUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetterOrDigit(e.KeyChar)) { e.Handled = true; }
        }

        private void txtBoxPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetterOrDigit(e.KeyChar)) { e.Handled = true; }
        }
    }
}
