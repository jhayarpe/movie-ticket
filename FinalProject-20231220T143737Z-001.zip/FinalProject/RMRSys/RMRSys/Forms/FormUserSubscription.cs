﻿using RMRSys.Model;
using RMRSys.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMRSys.Forms
{
    public partial class FormUserSubscription : Form
    {
        public long userID { get; set; }

        public FormUserSubscription(long userID)
        {
            InitializeComponent();
            this.userID = userID;
        }

        private void FormUserSubscription_Load(object sender, EventArgs e)
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                var user = (from subscription in db.tblSubscriptions
                            join subtype in db.tblSubscriptionTypes on subscription.SubTypeID equals subtype.SubTypeID
                            select new
                            {
                                subscription.UserID,
                                subtype.Type,
                                subscription.EndDate,
                                subscription.Expired
                            }).Where(x => x.UserID == userID && x.Expired == false).FirstOrDefault();
                lblStatus.Text += $"{user.Type.Trim()}";
                lblEnd.Text += $"{user.EndDate}";
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            Helper.ChangeForm(this, new FormUserHome(userID));
        }
    }
}
