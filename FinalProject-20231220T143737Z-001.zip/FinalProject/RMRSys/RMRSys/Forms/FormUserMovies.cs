﻿using RMRSys.Model;
using RMRSys.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMRSys.Forms
{
    public partial class FormUserMovies : Form
    {
        public long userID { get; set; }
        public string title { get; set; }
        public string genre { get; set; }
        public string releaseDate { get; set; }

        public FormUserMovies(long userID)
        {
            this.userID = userID;
            InitializeComponent();
            InitializeControls();
        }

        private void InitializeControls()
        {
            ToolTip tip = new ToolTip();
            tip.SetToolTip(txtBoxYear, "Year");
            tip.SetToolTip(txtBoxTitle, "Name of Movie");

            rBtnTitle.Checked = true;

            using (RMRSysEntities db = new RMRSysEntities())
            {
                List<tblGenres> genres = db.tblGenres.ToList();
                AddItem(genres, typeof(tblGenres), "GenreID", "Genre", "Select Genre");
                cmBoxGenre.DataSource = genres;
                cmBoxGenre.DisplayMember = "Genre";
                cmBoxGenre.ValueMember = "GenreID";
            }
        }

        // Add item to binded combo box
        private void AddItem(IList list, Type type, string valueMember, string displayMember, string displayText)
        {
            // create instance
            Object obj = Activator.CreateInstance(type);
            //set properties using property info
            PropertyInfo displayProperty =  type.GetProperty(displayMember);
            displayProperty.SetValue(obj, displayText);
            PropertyInfo valueProperty = type.GetProperty(valueMember);
            valueProperty.SetValue(obj, 0);
            list.Insert(0, obj);
        }

        //Grid Events
        private void LoadGrid()
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                this.moviesViewBindingSource.DataSource = db.moviesView.OrderBy(x=> x.Title).ToList();
            }
        }

        private void FormUser_Load(object sender, EventArgs e)
        {
            LoadGrid();
        }

        // Button Events
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                title = txtBoxTitle.Text.Trim();
                this.moviesViewBindingSource.DataSource = db.moviesView.Where(x => x.Title.Contains(title)).OrderBy(x => x.Title).ToList();
            }
        }

        private void BtnSort_Click(object sender, EventArgs e)
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                title = txtBoxTitle.Text.Trim();
                genre = cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem).Trim() == "Select Genre" ? "" : cmBoxGenre.GetItemText(cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem)).Trim();
                releaseDate = txtBoxYear.Text.Trim() == "Year" ? "" : txtBoxYear.Text.Trim();

                if (rBtnTitle.Checked)
                {
                    this.moviesViewBindingSource.DataSource = db.moviesView.Where(x => x.Title.Contains(title) && x.Genre.Contains(genre) && x.ReleaseDate.Year.ToString().Contains(releaseDate)).OrderBy(x => x.Title).ToList();
                }
                else if (rBtnGenre.Checked)
                {
                    this.moviesViewBindingSource.DataSource = db.moviesView.Where(x => x.Title.Contains(title) && x.Genre.Contains(genre) && x.ReleaseDate.Year.ToString().Contains(releaseDate)).OrderBy(x => x.Genre).ToList();
                }
                else
                {
                    this.moviesViewBindingSource.DataSource = db.moviesView.Where(x => x.Title.Contains(title) && x.Genre.Contains(genre) && x.ReleaseDate.Year.ToString().Contains(releaseDate)).OrderBy(x => x.ReleaseDate).ToList();
                }
            }
        }

        private void BtnFilter_Click(object sender, EventArgs e)
        {
            using (RMRSysEntities db = new RMRSysEntities())
            {
                title = txtBoxTitle.Text.Trim();
                genre = cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem).Trim() == "Select Genre" ? "" : cmBoxGenre.GetItemText(cmBoxGenre.GetItemText(cmBoxGenre.SelectedItem)).Trim();
                releaseDate = txtBoxYear.Text.Trim() == "Year" ? "" : txtBoxYear.Text.Trim();


                this.moviesViewBindingSource.DataSource = db.moviesView.Where(x => x.Title.Contains(title) && x.Genre.Contains(genre) && x.ReleaseDate.Year.ToString().Contains(releaseDate)).OrderBy(x => x.Title).ToList();
            }
        }

        private void BtnRent_Click(object sender, EventArgs e)
        {
            if (Helper.Mbox("Proceed to payment?", "Information", MessageBoxButtons.YesNo, MessageBoxIcon.Information, DialogResult.Yes))
            {
                ArrayList selectedMovies = new ArrayList();

                foreach (DataGridViewRow row in gridMovies.SelectedRows)
                {
                    moviesView movie = new moviesView();
                    movie.MovieID = row.Cells[0].Value.ToString();
                    movie.Title = row.Cells[1].Value.ToString();
                    movie.Genre = row.Cells[2].Value.ToString();
                    movie.ReleaseDate = (DateTime)row.Cells[3].Value;

                    selectedMovies.Add(movie);
                }

                Helper.ChangeForm(this, new FormUserRent(userID, selectedMovies));
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            Helper.ChangeForm(this, new FormUserHome(userID));
        }

        // Keypress Event
        private void TxtBoxYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) { e.Handled = true; }
        }

        // On click Event
        private void TxtBoxYear_MouseClick(object sender, MouseEventArgs e)
        {
            txtBoxYear.SelectionStart = 0;
            txtBoxYear.SelectionLength = txtBoxYear.TextLength;
        }
    }
}
